import axios from 'axios';
export const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1', withCredentials: true });
export type User = {id:number;name:string;email:string;role:string;user_type:string};
export type Outlet = {id:number;name:string;slug:string;description:string;location:string;status:string};
export type Food = {id:number;outlet_id:number;category_id:number;name:string;description:string;price:number;image_url:string;prep_minutes:number;dietary_type:string;is_jain:boolean;is_available:boolean;available_quantity:number|null};
