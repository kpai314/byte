from datetime import datetime, timedelta, timezone
import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session
from .config import settings
from .database import get_db
from .models import User

password_hash = PasswordHasher()
ALGORITHM = "HS256"
def hash_password(password: str) -> str: return password_hash.hash(password)
def verify_password(password: str, hashed: str) -> bool:
    try: return password_hash.verify(hashed, password)
    except VerifyMismatchError: return False
def create_token(user: User) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.access_token_minutes)
    return jwt.encode({"sub": str(user.id), "exp": exp}, settings.secret_key, algorithm=ALGORITHM)
def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get("byte_session")
    if not token: raise HTTPException(401, "Please log in")
    try: payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM]); user_id = int(payload["sub"])
    except Exception: raise HTTPException(401, "Session expired")
    user = db.get(User, user_id)
    if not user or not user.is_active: raise HTTPException(401, "Account unavailable")
    return user
def require_roles(*roles):
    def check(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(403, "Insufficient permissions")
        return user
    return check
