from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from . import models
from .routers import auth, catalog, orders, admin

app = FastAPI(title=settings.app_name, version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_origins.split(",")], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router); app.include_router(catalog.router); app.include_router(orders.router); app.include_router(admin.router)
@app.get("/api/health")
def health(): return {"status": "ok", "service": "BYTE API"}
