from uuid import uuid4
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Order, OrderItem, FoodItem, OutletMembership, User, OrderStatusHistory
from ..schemas import CheckoutIn, StatusIn
from ..security import current_user
router = APIRouter(prefix="/api/v1", tags=["orders"])
@router.post("/checkout")
def checkout(data: CheckoutIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = db.query(Order).filter_by(idempotency_key=data.idempotency_key).first()
    if existing:
        if existing.user_id != user.id: raise HTTPException(409, "Idempotency key already used")
        return {"id": existing.id, "order_number": existing.order_number, "status": existing.status, "total": float(existing.total), "payment_status": existing.payment_status, "message": "Existing sandbox order returned; no additional charge was created."}
    if not data.items: raise HTTPException(400, "Your cart is empty")
    ids = [x.food_item_id for x in data.items]
    if len(ids) != len(set(ids)): raise HTTPException(400, "Duplicate cart lines are not allowed")
    items = db.query(FoodItem).filter(FoodItem.id.in_(ids), FoodItem.outlet_id == data.outlet_id, FoodItem.is_active == True).all()
    if len(items) != len(ids): raise HTTPException(400, "One or more items are unavailable or belong to another outlet")
    by_id = {i.id: i for i in items}; total = Decimal("0.00")
    for line in data.items:
        item = by_id[line.food_item_id]
        if not item.is_available: raise HTTPException(409, f"{item.name} is currently unavailable")
        if item.available_quantity is not None and item.available_quantity < line.quantity: raise HTTPException(409, f"Insufficient stock for {item.name}")
        total += Decimal(str(item.price)) * line.quantity
    order = Order(order_number="BY-" + uuid4().hex[:8].upper(), user_id=user.id, outlet_id=data.outlet_id, idempotency_key=data.idempotency_key, status="PLACED", subtotal=total, total=total)
    db.add(order); db.flush(); db.add(OrderStatusHistory(order_id=order.id, previous_status=None, new_status="PLACED", changed_by=user.id))
    for line in data.items:
        item = by_id[line.food_item_id]
        db.add(OrderItem(order_id=order.id, food_item_id=item.id, item_name_snapshot=item.name, unit_price=item.price, quantity=line.quantity, line_total=Decimal(str(item.price))*line.quantity))
        if item.available_quantity is not None: item.available_quantity -= line.quantity
    db.commit(); db.refresh(order)
    return {"id": order.id, "order_number": order.order_number, "status": order.status, "total": float(order.total), "payment_status": "SANDBOX_SUCCESS", "message": "Sandbox checkout only — no real payment was collected."}
@router.get("/orders/mine")
def my_orders(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Order).filter_by(user_id=user.id).order_by(Order.created_at.desc()).all()
    return [{"id":o.id,"order_number":o.order_number,"outlet_id":o.outlet_id,"status":o.status,"total":float(o.total),"created_at":o.created_at,"items":[{"name":i.item_name_snapshot,"quantity":i.quantity} for i in o.items]} for o in rows]
@router.get("/vendor/orders")
def vendor_orders(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role not in ["admin", "vendor", "outlet_staff"]: raise HTTPException(403, "Vendor access required")
    ids = None if user.role == "admin" else [m.outlet_id for m in db.query(OutletMembership).filter_by(user_id=user.id,is_active=True).all()]
    q = db.query(Order).order_by(Order.created_at.asc())
    if ids is not None: q = q.filter(Order.outlet_id.in_(ids))
    return [{"id":o.id,"order_number":o.order_number,"outlet_id":o.outlet_id,"status":o.status,"total":float(o.total),"items":[{"name":i.item_name_snapshot,"quantity":i.quantity} for i in o.items]} for o in q.limit(100).all()]
@router.patch("/vendor/orders/{order_id}/status")
def update_status(order_id: int, data: StatusIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role not in ["admin", "vendor", "outlet_staff"]: raise HTTPException(403, "Vendor access required")
    order = db.get(Order, order_id)
    if not order: raise HTTPException(404, "Order not found")
    if user.role != "admin":
        membership = db.query(OutletMembership).filter_by(user_id=user.id,outlet_id=order.outlet_id,is_active=True).first()
        if not membership: raise HTTPException(403, "Outlet access denied")
    allowed = {"PLACED": ["PREPARING", "CANCELLED"], "PREPARING": ["READY"], "READY": ["COMPLETED"]}
    if data.status not in allowed.get(order.status, []): raise HTTPException(400, "Invalid order status transition")
    previous = order.status; order.status = data.status; db.add(OrderStatusHistory(order_id=order.id, previous_status=previous, new_status=data.status, changed_by=user.id)); db.commit(); return {"id": order.id, "status": order.status}
