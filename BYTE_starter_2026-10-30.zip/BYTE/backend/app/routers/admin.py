from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User, Outlet, OutletMembership
from ..security import require_roles, hash_password

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    user_type: str = "student"
    role: str = "user"
    campus_id: str | None = None
class OutletCreate(BaseModel):
    name: str
    slug: str
    description: str = ""
    location: str = "Campus"
class MembershipCreate(BaseModel):
    user_id: int
    outlet_role: str = "vendor"

@router.post("/users")
def create_user(data: UserCreate, _admin=Depends(require_roles("admin")), db: Session=Depends(get_db)):
    if data.role not in {"user", "vendor", "outlet_staff", "admin"}: raise HTTPException(400, "Unsupported role")
    if db.query(User).filter(User.email==data.email.lower()).first(): raise HTTPException(409, "Email already exists")
    row=User(name=data.name,email=data.email.lower(),password_hash=hash_password(data.password),user_type=data.user_type,role=data.role,campus_id=data.campus_id)
    db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"name":row.name,"email":row.email,"role":row.role}
@router.post("/outlets")
def create_outlet(data: OutletCreate, _admin=Depends(require_roles("admin")), db: Session=Depends(get_db)):
    if db.query(Outlet).filter(Outlet.slug==data.slug).first(): raise HTTPException(409,"Outlet slug already exists")
    row=Outlet(**data.model_dump()); db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"name":row.name,"slug":row.slug}
@router.post("/outlets/{outlet_id}/members")
def add_member(outlet_id:int,data:MembershipCreate,_admin=Depends(require_roles("admin")),db:Session=Depends(get_db)):
    if not db.get(Outlet,outlet_id) or not db.get(User,data.user_id): raise HTTPException(404,"Outlet or user not found")
    if db.query(OutletMembership).filter_by(outlet_id=outlet_id,user_id=data.user_id).first(): raise HTTPException(409,"Membership already exists")
    row=OutletMembership(outlet_id=outlet_id,user_id=data.user_id,outlet_role=data.outlet_role);db.add(row);db.commit();return {"ok":True}
