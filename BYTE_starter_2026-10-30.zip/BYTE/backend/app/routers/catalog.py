from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from ..database import get_db
from ..models import Outlet, MenuCategory, FoodItem, OutletMembership, User
from ..schemas import OutletOut, FoodOut, FoodCreate, CategoryCreate, CategoryOut
from ..security import current_user, require_roles
router = APIRouter(prefix="/api/v1", tags=["catalog"])
@router.get("/outlets", response_model=list[OutletOut])
def outlets(db: Session = Depends(get_db)):
    return db.query(Outlet).filter(Outlet.status == "active").order_by(Outlet.name).all()
@router.get("/outlets/{outlet_id}/menu")
def menu(outlet_id: int, db: Session = Depends(get_db)):
    outlet = db.get(Outlet, outlet_id)
    if not outlet or outlet.status != "active": raise HTTPException(404, "Outlet not found")
    cats = db.query(MenuCategory).options(joinedload(MenuCategory.items)).filter(MenuCategory.outlet_id == outlet_id, MenuCategory.is_active == True).order_by(MenuCategory.display_order).all()
    return [{"id": c.id, "name": c.name, "items": [FoodOut.model_validate(i).model_dump() for i in c.items if i.is_active]} for c in cats]
def vendor_outlet_ids(user: User, db: Session):
    if user.role == "admin": return None
    return [m.outlet_id for m in db.query(OutletMembership).filter_by(user_id=user.id, is_active=True).all()]
@router.get("/vendor/outlets")
def vendor_outlets(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role not in ["admin", "vendor", "outlet_staff"]: raise HTTPException(403, "Vendor access required")
    ids = vendor_outlet_ids(user, db)
    q = db.query(Outlet)
    if ids is not None: q = q.filter(Outlet.id.in_(ids))
    return q.all()
@router.post("/vendor/outlets/{outlet_id}/categories", response_model=CategoryOut)
def create_category(outlet_id: int, data: CategoryCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role != "admin" and outlet_id not in (vendor_outlet_ids(user, db) or []): raise HTTPException(403, "Outlet access denied")
    if not db.get(Outlet, outlet_id): raise HTTPException(404, "Outlet not found")
    row = MenuCategory(outlet_id=outlet_id, name=data.name.strip()); db.add(row); db.commit(); db.refresh(row); return row
@router.post("/vendor/outlets/{outlet_id}/items", response_model=FoodOut)
def create_item(outlet_id: int, data: FoodCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role != "admin" and outlet_id not in (vendor_outlet_ids(user, db) or []): raise HTTPException(403, "Outlet access denied")
    cat = db.get(MenuCategory, data.category_id)
    if not cat or cat.outlet_id != outlet_id: raise HTTPException(400, "Category must belong to this outlet")
    row = FoodItem(outlet_id=outlet_id, **data.model_dump()); db.add(row); db.commit(); db.refresh(row); return row
@router.patch("/vendor/items/{item_id}/availability")
def availability(item_id: int, is_available: bool, user: User = Depends(current_user), db: Session = Depends(get_db)):
    item = db.get(FoodItem, item_id)
    if not item: raise HTTPException(404, "Item not found")
    if user.role != "admin" and item.outlet_id not in (vendor_outlet_ids(user, db) or []): raise HTTPException(403, "Outlet access denied")
    item.is_available = is_available; db.commit(); return {"id": item.id, "is_available": item.is_available}
