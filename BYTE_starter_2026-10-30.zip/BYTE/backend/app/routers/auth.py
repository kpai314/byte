from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import User
from ..schemas import LoginIn, UserOut
from ..security import verify_password, create_token, current_user
router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
@router.post("/login", response_model=UserOut)
def login(data: LoginIn, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email.lower()).first()
    if not user or not verify_password(data.password, user.password_hash): raise HTTPException(401, "Incorrect email or password")
    if not user.is_active: raise HTTPException(403, "Account is inactive")
    response.set_cookie("byte_session", create_token(user), httponly=True, samesite="lax", secure=False, max_age=43200)
    return user
@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("byte_session"); return {"ok": True}
@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)): return user
