from .database import Base, engine, SessionLocal
from .models import User, Outlet, OutletMembership, MenuCategory, FoodItem
from .security import hash_password
Base.metadata.create_all(bind=engine)
db=SessionLocal()
try:
    users = {}
    for email,name,role,kind,password in [
        ("admin@example.com","BYTE Administrator","admin","staff","ByteAdmin123!"),
        ("vendor@example.com","Dabba Lab Vendor","vendor","staff","ByteVendor123!"),
        ("vendor.tiffin@example.com","Tiffin Express Vendor","vendor","staff","ByteVendor123!"),
        ("vendor.chai@example.com","Chai & Crumb Vendor","vendor","staff","ByteVendor123!"),
        ("student@example.com","Demo Student","user","student","ByteStudent123!")]:
        u=db.query(User).filter_by(email=email).first()
        if not u: u=User(name=name,email=email,role=role,user_type=kind,password_hash=hash_password(password)); db.add(u); db.flush()
        users[email]=u
    outlets_data=[("Dabba Lab","dabba-lab","Everyday comfort meals, made fresh.","Main Campus"),("Tiffin Express","tiffin-express","South Indian breakfasts and quick bites.","Food Court"),("Chai & Crumb","chai-crumb","Tea, coffee, bakery and evening snacks.","Library Lane")]
    for outlet_index,(name,slug,desc,loc) in enumerate(outlets_data):
        o=db.query(Outlet).filter_by(slug=slug).first()
        if not o: o=Outlet(name=name,slug=slug,description=desc,location=loc); db.add(o); db.flush()
        vendor_user = [users["vendor@example.com"], users["vendor.tiffin@example.com"], users["vendor.chai@example.com"]][outlet_index]
        if not db.query(OutletMembership).filter_by(outlet_id=o.id,user_id=vendor_user.id).first(): db.add(OutletMembership(outlet_id=o.id,user_id=vendor_user.id,outlet_role="vendor"))
        if not o.categories:
            c1=MenuCategory(outlet_id=o.id,name="Popular",display_order=1); c2=MenuCategory(outlet_id=o.id,name="Meals & Mains",display_order=2); db.add_all([c1,c2]); db.flush()
            samples=[("Paneer Butter Masala","Creamy tomato gravy with soft paneer.",169,"veg",False,18,"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=900"),("Veg Thali","A balanced everyday meal with seasonal sides.",129,"veg",False,12,"https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=900"),("Masala Dosa","Crisp dosa with spiced potato filling.",89,"veg",False,10,"https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=900"),("Chicken Biryani","Fragrant rice layered with spiced chicken.",189,"non_veg",False,20,"https://images.unsplash.com/photo-1563379091339-03246963d96c?w=900"),("Cutting Chai","Strong, milky campus-style tea.",20,"veg",False,4,"https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=900")]
            for idx,(n,d,p,dt,j,prep,img) in enumerate(samples): db.add(FoodItem(outlet_id=o.id,category_id=c1.id if idx in [0,2,4] else c2.id,name=n,description=d,price=p,dietary_type=dt,is_jain=j,prep_minutes=prep,image_url=img,is_available=idx!=3,available_quantity=30 if idx!=3 else 0))
    db.commit(); print("BYTE demo data ready")
finally: db.close()
