from pydantic import BaseModel, EmailStr, ConfigDict, Field
from typing import Optional

class LoginIn(BaseModel): email: EmailStr; password: str
class UserOut(BaseModel): id: int; name: str; email: EmailStr; role: str; user_type: str
class OutletOut(BaseModel): id: int; name: str; slug: str; description: str; location: str; status: str
class CategoryOut(BaseModel): id: int; name: str; display_order: int
class FoodOut(BaseModel):
    id: int; outlet_id: int; category_id: int; name: str; description: str; price: float; image_url: str; prep_minutes: int; dietary_type: str; is_jain: bool; is_available: bool; available_quantity: Optional[int] = None
    model_config = ConfigDict(from_attributes=True)
class FoodCreate(BaseModel): category_id: int; name: str; description: str = ""; price: float = Field(gt=0); image_url: str = ""; prep_minutes: int = Field(default=10, ge=1); dietary_type: str = "veg"; is_jain: bool = False; is_available: bool = True; available_quantity: Optional[int] = None
class CategoryCreate(BaseModel): name: str
class OrderItemIn(BaseModel): food_item_id: int; quantity: int = Field(ge=1, le=20)
class CheckoutIn(BaseModel): outlet_id: int; items: list[OrderItemIn]; idempotency_key: str
class StatusIn(BaseModel): status: str
