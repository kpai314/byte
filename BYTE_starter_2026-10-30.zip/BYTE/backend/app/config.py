from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "BYTE API"
    database_url: str = "sqlite:///./byte.db"
    secret_key: str = "local-development-secret-change-me"
    access_token_minutes: int = 720
    cors_origins: str = "http://localhost:5173"
    campus_name: str = "DJSCE"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
