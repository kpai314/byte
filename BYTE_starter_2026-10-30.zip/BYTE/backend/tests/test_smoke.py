"""Basic API smoke tests. Run after `alembic upgrade head` and `python -m app.seed`."""
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def login(email="student@example.com", password="ByteStudent123!"):
    return client.post("/api/v1/auth/login", json={"email": email, "password": password})

def test_health_and_catalog():
    assert client.get("/api/health").status_code == 200
    assert login().status_code == 200
    outlets = client.get("/api/v1/outlets").json()
    assert len(outlets) >= 3
    assert client.get(f"/api/v1/outlets/{outlets[0]['id']}/menu").status_code == 200

def test_vendor_is_outlet_scoped():
    client.post("/api/v1/auth/logout")
    assert login("vendor@example.com", "ByteVendor123!").status_code == 200
    outlets = client.get("/api/v1/vendor/outlets").json()
    assert len(outlets) == 1
    assert outlets[0]["slug"] == "dabba-lab"
