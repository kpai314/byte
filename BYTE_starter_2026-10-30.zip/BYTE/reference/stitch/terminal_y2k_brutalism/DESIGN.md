---
name: Terminal Y2K Brutalism
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#464558'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#767589'
  outline-variant: '#c6c4db'
  surface-tint: '#4238ff'
  primary: '#1c00bd'
  on-primary: '#ffffff'
  primary-container: '#2a00ff'
  on-primary-container: '#bbbaff'
  inverse-primary: '#c2c1ff'
  secondary: '#676000'
  on-secondary: '#ffffff'
  secondary-container: '#f3e300'
  on-secondary-container: '#6c6400'
  tertiary: '#770004'
  on-tertiary: '#ffffff'
  tertiary-container: '#a20007'
  on-tertiary-container: '#ffaba0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#0b006b'
  on-primary-fixed-variant: '#2500e8'
  secondary-fixed: '#f6e600'
  secondary-fixed-dim: '#d8ca00'
  on-secondary-fixed: '#1f1c00'
  on-secondary-fixed-variant: '#4e4800'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4aa'
  on-tertiary-fixed: '#410001'
  on-tertiary-fixed-variant: '#930006'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.04em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 22px
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.1em
  code-dense:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 13px
    letterSpacing: 0em
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an uncompromising fusion of high-density retro-futurism, indie Y2K cyber-kitsch, and raw neo-brutalist utility, heavily infused with the kinetic rhythm of Mumbai transit and street culture. Built for a fast-paced university canteen environment, the interface feels like an interactive terminal hybrid: part arcade cabinet, part Mumbai suburban local railway automated ticket machine, part 2000s cyber-zine.

The visual narrative relies on absolute raw contrast, unapologetic structural black scaffolding, high-visibility neon accents, and dense information architecture. It eliminates digital illusions like blur, feathering, and gradients in favor of sharp lines, high-impact solid color fills, thermal receipt serrations, and mechanical hardware cues. The user experience is immediate, visceral, tactile, and engineered to turn chaotic lunchtime rushes into high-energy, rapid-fire micro-interactions.

## Colors

The palette operates on strict, unyielding rules. No gradients, radial blends, or translucent blurs are permitted under any condition. All transitions between color volumes must be razor-sharp cuts defined by solid fills or structural black borders.

- **Pure White (`#FFFFFF`):** High-key primary canvas, receipt body surfaces, card foundations, and inverse typography blocks.
- **Jet Black (`#000000`):** The structural bone layer. Used for borders, structural frames, solid punch-out badges, text, and hard mechanical shadows.
- **Electric Neon Blue (`#2A00FF`):** The core hyper-link and active vector. Drives focus rings, navigation tabs, selected states, and retro arcade highlights.
- **Neon Yellow (`#F9E900`):** Kinetic accent and high-friction interruptor. Applied to flash deals, "READY FOR PICKUP" banners, dynamic tokens, stickers, and interactive primary CTAs.
- **Signal Red (`#DD1C1A`):** Critical status indicator. Dictates spicy/hot food markers, stock warnings, terminal cancellations, and urgent pickup timers.
- **Sub-surface Patterning:** High-contrast 2x2 and 4x4 alternating checkered fills (`#000000` on `#FFFFFF` or `#2A00FF` on `#FFFFFF`) used exclusively for structural dividers and card headers.

## Typography

Typography functions as both functional data display and graphic brutalist infrastructure:

- **Headlines (`Space Grotesk`):** Heavyweight, aggressively tight tracking, always displayed in uppercase or sentence case with zero tolerance for ornamental flourishes. Used for screen designations, food category announcements, and price bursts.
- **Micro-Typography & Thermal Receipts (`Space Mono`):** Fixed-width monospaced architecture used for token identifiers, ticket codes, nutrition facts, item modifiers, terminal clock timestamps, and ASCII receipt separators (`====================`).
- **Stylistic Text Treatments:** All interactive labels, category filters, and action verbs are set in all-caps with generous character spacing to mimic dot-matrix prints and stamped railway coupons.

## Layout & Spacing

The layout is anchored in dense, high-efficiency grid frameworks reminiscent of printed trade gazettes and arcade machine layout plates:

- **Grid Framework:** A rigid 12-column modular grid on desktop (1280px+), collapsing to an 8-column layout on tablet (768px - 1024px), and a tight 4-column column layout on mobile screens (&lt;768px).
- **Rhythm & Partitioning:** Elements are tightly packed using modular 4px base units. Sections are segregated not by blank space, but by hard 2px or 3px solid black containment borders, ticker-tape strips, or contrasting color-block ribbons.
- **Edge Containment:** Content respects hard screen margins while allowing high-impact visual banners (such as live queue status tickers or neon promotional tapes) to break out full bleed to the viewport perimeter.

## Elevation & Depth

True to neo-brutalist fundamentals, elevation avoids soft drop-shadows, blurred layers, and atmospheric depth maps:

- **Hard-Offset Shadow (Standard):** `3px 3px 0px #000000`. Applied to primary cards, item blocks, and static input panels to create a stamped cardboard/physical chip presence.
- **High-Impact Shadow (Floating / Active):** `5px 5px 0px #000000` or `4px 4px 0px #2A00FF`. Applied to elevated drawer panels, critical alert dialogs, and interactive hover states.
- **Depressed / Active Depth (Zero Offset):** `0px 0px 0px #000000` combined with a positive transform `translate(3px, 3px)` to emulate a mechanical key-switch being firmly pressed downward.
- **Surface Layering:** Hierarchy is generated through raw stacking orders: Neon Yellow action chips sitting directly on Pure White cards bound by 3px solid Jet Black bounding boxes.

## Shapes

The design system enforces strict industrial geometry with zero edge rounding:

- **Radius:** Sharp 0px corners across every button, card, modal, badge, input, and avatar. No rounded corners or circular pills are allowed.
- **Architectural Cutouts:** Ticket notches and receipt cutouts are formed via pure geometric 45-degree chamfers or hard right-angle negative spaces cut directly out of corner bounding boxes.
- **Stamps & Badges:** Rotated square badges (e.g., `-3deg` or `4deg` rotation) to evoke physical hand-stamped ink impressions from Mumbai transport ticketing desks.
- **Dividers & Borders:** Jagged zig-zag saw-tooth cut edges for digital receipts and coupon perforations.

## Components

- **Buttons:**
  - *Primary Button:* Solid `#F9E900` fill, 3px solid `#000000` border, `Space Grotesk` uppercase bold text, hard shadow `3px 3px 0px #000000`. On active/press: `translate(3px, 3px)` with `box-shadow: none`.
  - *Electric Terminal Button:* Solid `#2A00FF` fill with crisp `#FFFFFF` uppercase text, 3px solid `#000000` border, offset `3px 3px 0px #000000`.
  - *Destructive / Rush Button:* Solid `#DD1C1A` fill, `#FFFFFF` text, 3px solid `#000000` border.
- **Chips & Filter Pills:**
  - Sharp rectangular tags with 2px solid `#000000` borders. Unselected: `#FFFFFF` fill with black monospace text. Selected: inverted to solid `#000000` background with white text or solid `#2A00FF` with white text.
- **Cards (Food Item & Canteen Stalls):**
  - Crisp `#FFFFFF` card body with a continuous 3px solid `#000000` border and `4px 4px 0px #000000` offset shadow.
  - Header strips feature a 20px high black-and-white checkered bar or solid neon strip housing the item category and stall ID code.
  - Photography frame: 1:1 square crop featuring 0.5x ultra-wide fisheye canteen dishes shot with harsh Y2K digicam direct-flash lighting, bounded by a 2px interior black frame.
- **Order Receipts & Digital Tokens:**
  - White vertical layout styled as a thermal roll printout with a saw-tooth zig-zag bottom edge.
  - Includes rendered 1D barcodes, terminal verification code in `Space Mono`, ASCII dot-line spacers, and an oversized rotated "PAID / VERIFIED" rubber-stamp badge in `#DD1C1A`.
- **Inputs & Search Terminals:**
  - 3px solid `#000000` border, `#FFFFFF` background, solid black text. Focus state triggers a solid `#2A00FF` hard border and a high-visibility `#F9E900` focus ring offset. Cursor is rendered as a thick blinking retro block.
- **Checkboxes & Radios:**
  - 18px x 18px solid black square boxes. Check state displays an 8-bit chunky inverted pixel cross (`X`) or solid `#2A00FF` square block fill.
- **Live Status Ticker:**
  - Continuous running marquee banner with solid `#F9E900` or `#2A00FF` background, bounded by 2px top and bottom black borders, broadcasting canteen prep queues, stall wait times, and kitchen notifications in `Space Mono` bold.