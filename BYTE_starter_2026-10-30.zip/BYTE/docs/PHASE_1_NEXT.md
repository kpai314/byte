# Next implementation tasks

1. Complete frontend dependency install/build and run browser QA at mobile/tablet/desktop breakpoints.
2. Port and refine canonical Stitch home, directory, item detail and thermal receipt layouts screen-by-screen; the current app is a functional first-pass interpretation, not a pixel-perfect migration.
3. Add invitation/activation workflow and admin console UI.
4. Add food-item edit/deactivate, category management UI and local/cloud image upload.
5. Add QR pickup token generation and server-side collection verification.
6. Add user-visible live order timeline and order status history UI; then WebSocket updates.
7. Add reviews, reservation workflow and the remaining UI-derived feature backlog in later phases.
8. Add concurrency-safe inventory updates and production security hardening.
9. Replace remote demo food image URLs with licensed local assets.
