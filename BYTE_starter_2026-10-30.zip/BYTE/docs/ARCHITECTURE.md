# BYTE architecture — initial implementation

## Shape
Modular monolith: React/Vite client → FastAPI `/api/v1` → SQLAlchemy → PostgreSQL. SQLite is the local fallback. No microservices.

## Modules
- `auth`: login, logout, current session.
- `catalog`: outlet discovery, menu reads, vendor menu/category and availability writes.
- `orders`: server-side checkout, order history, vendor queue and validated status transitions.
- `admin`: account/outlet provisioning and outlet memberships.

## Authorization
Roles are `admin`, `vendor`, `outlet_staff`, `user`. Vendor access is scoped by `outlet_memberships`; admin endpoints use admin-only dependencies. Every order update checks outlet membership.

## Money and payments
All checkout totals are recomputed from database prices. The current checkout is a sandbox confirmation and explicitly collects no money. There is no real wallet or gateway integration. Integrate an approved payment provider only after campus/legal review of the wallet/payment arrangement.

## Next hardening work
Secure cookie configuration per environment, CSRF strategy, invitation/activation flow, rate limits, audit logs, full status-history read endpoints, pickup QR verification, payment webhook verification and concurrency-safe inventory decrement.
