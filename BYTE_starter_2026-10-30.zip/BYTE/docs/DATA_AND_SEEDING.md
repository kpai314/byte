# Data and seeding

The demo seed script creates one admin, three separately scoped outlet vendors, one student, three outlets, two categories per outlet and five synthetic menu listings per outlet. The seed is repeatable and does not duplicate existing users/outlets/categories.

Demo dishes/prices and stock are synthetic. Food image URLs are temporary Unsplash-hosted references and must be replaced with owned/licensed assets before production. Jain status is not inferred; seeded items default to `false`.

Run from `backend/`:
```bash
alembic upgrade head
python -m app.seed
```

Do not import a recipe dataset directly as a live menu. A dish catalogue and outlet menu listing are different: price, availability, preparation time and stock belong to the outlet's listing. Verify dataset licences and image rights before importing external data.
