import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';

const DB_PATH = path.resolve(process.cwd(), 'byte_campus.db');

export const db = new Database(DB_PATH);

// Enforce foreign keys and WAL mode for high concurrency
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase() {
  console.log('[BYTE DB] Initializing persistent SQLite relational database at', DB_PATH);

  // 1. Schema Migrations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      version TEXT NOT NULL UNIQUE,
      description TEXT,
      applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 2. Core Tables
  db.exec(`
    -- Campuses
    CREATE TABLE IF NOT EXISTS campuses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      location TEXT NOT NULL,
      campus_code TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Users
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      phone TEXT,
      password_hash TEXT NOT NULL,
      campus_id TEXT,
      user_category TEXT NOT NULL CHECK(user_category IN ('Student', 'Faculty', 'Non-teaching staff')),
      operational_role TEXT NOT NULL CHECK(operational_role IN ('User', 'Admin', 'Vendor', 'Outlet staff')),
      account_status TEXT NOT NULL DEFAULT 'active' CHECK(account_status IN ('active', 'inactive', 'pending_activation')),
      reset_token TEXT,
      reset_token_expires DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- User Sessions
    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Outlets
    CREATE TABLE IF NOT EXISTS outlets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campus_id INTEGER NOT NULL REFERENCES campuses(id) ON DELETE RESTRICT,
      outlet_name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      location TEXT NOT NULL,
      opening_time TEXT NOT NULL DEFAULT '08:00',
      closing_time TEXT NOT NULL DEFAULT '20:00',
      outlet_status TEXT NOT NULL DEFAULT 'active' CHECK(outlet_status IN ('active', 'closed', 'renovating')),
      crowd_level TEXT NOT NULL DEFAULT 'MODERATE' CHECK(crowd_level IN ('LOW', 'MODERATE', 'HIGH')),
      avg_wait_min INTEGER NOT NULL DEFAULT 10,
      vendor_owner_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Outlet Staff Memberships
    CREATE TABLE IF NOT EXISTS outlet_staff (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      staff_role TEXT NOT NULL CHECK(staff_role IN ('manager', 'cashier', 'cook', 'vendor')),
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'inactive')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(outlet_id, user_id)
    );

    -- Menu Categories
    CREATE TABLE IF NOT EXISTS menu_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      category_name TEXT NOT NULL,
      description TEXT,
      display_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Menu Items
    CREATE TABLE IF NOT EXISTS menu_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      category_id INTEGER NOT NULL REFERENCES menu_categories(id) ON DELETE RESTRICT,
      item_name TEXT NOT NULL,
      description TEXT,
      price REAL NOT NULL CHECK(price >= 0),
      image_url TEXT,
      food_type TEXT NOT NULL CHECK(food_type IN ('veg', 'non_veg', 'jain')),
      dietary_tags TEXT DEFAULT '[]',
      allergens TEXT DEFAULT '[]',
      preparation_time INTEGER NOT NULL DEFAULT 10 CHECK(preparation_time >= 0),
      availability_status TEXT NOT NULL DEFAULT 'available' CHECK(availability_status IN ('available', 'sold_out', 'paused')),
      stock_quantity INTEGER DEFAULT 50 CHECK(stock_quantity IS NULL OR stock_quantity >= 0),
      display_order INTEGER NOT NULL DEFAULT 0,
      rating REAL DEFAULT 4.8,
      is_popular INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Outlet Physical Tables
    CREATE TABLE IF NOT EXISTS outlet_tables (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      table_number TEXT NOT NULL,
      capacity INTEGER NOT NULL CHECK(capacity > 0),
      status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available', 'occupied', 'reserved')),
      location TEXT NOT NULL,
      reserved_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      reserved_by_name TEXT,
      expires_at TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(outlet_id, table_number)
    );

    -- Table Reservations
    CREATE TABLE IF NOT EXISTS table_reservations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reservation_number TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      table_id INTEGER NOT NULL REFERENCES outlet_tables(id) ON DELETE CASCADE,
      reservation_date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      party_size INTEGER NOT NULL CHECK(party_size > 0),
      reservation_status TEXT NOT NULL DEFAULT 'active' CHECK(reservation_status IN ('active', 'completed', 'cancelled', 'expired')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Orders
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      idempotency_key TEXT UNIQUE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE RESTRICT,
      subtotal REAL NOT NULL CHECK(subtotal >= 0),
      taxes REAL NOT NULL DEFAULT 0 CHECK(taxes >= 0),
      discounts REAL NOT NULL DEFAULT 0 CHECK(discounts >= 0),
      total_amount REAL NOT NULL CHECK(total_amount >= 0),
      payment_status TEXT NOT NULL DEFAULT 'SANDBOX_SUCCESS' CHECK(payment_status IN ('SANDBOX_SUCCESS', 'CASH_AT_COUNTER', 'PENDING', 'FAILED')),
      order_status TEXT NOT NULL DEFAULT 'PLACED' CHECK(order_status IN ('PLACED', 'PREPARING', 'READY', 'COMPLETED', 'CANCELLED')),
      pickup_counter TEXT NOT NULL,
      pickup_type TEXT NOT NULL DEFAULT 'immediate' CHECK(pickup_type IN ('immediate', 'scheduled')),
      scheduled_time TEXT,
      pickup_token TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Order Items (Receipt Snapshots)
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      menu_item_id INTEGER REFERENCES menu_items(id) ON DELETE SET NULL,
      item_name_snapshot TEXT NOT NULL,
      unit_price_snapshot REAL NOT NULL CHECK(unit_price_snapshot >= 0),
      quantity INTEGER NOT NULL CHECK(quantity > 0),
      selected_options TEXT DEFAULT '{}',
      item_total REAL NOT NULL CHECK(item_total >= 0)
    );

    -- Payments
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      payment_provider TEXT NOT NULL DEFAULT 'SANDBOX_UPI',
      payment_reference TEXT NOT NULL UNIQUE,
      amount REAL NOT NULL CHECK(amount >= 0),
      payment_method TEXT NOT NULL CHECK(payment_method IN ('upi', 'cash', 'card')),
      payment_status TEXT NOT NULL DEFAULT 'COMPLETED' CHECK(payment_status IN ('COMPLETED', 'PENDING', 'FAILED')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Reviews
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      outlet_id INTEGER NOT NULL REFERENCES outlets(id) ON DELETE CASCADE,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
      review_text TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, order_id)
    );

    -- Media Assets
    CREATE TABLE IF NOT EXISTS media_assets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      outlet_id INTEGER REFERENCES outlets(id) ON DELETE SET NULL,
      media_type TEXT NOT NULL CHECK(media_type IN ('image', 'video', 'badge')),
      media_url TEXT NOT NULL,
      thumbnail_url TEXT,
      alt_text TEXT,
      title TEXT,
      duration_seconds INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Notifications
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'order' CHECK(type IN ('order', 'pickup', 'rush', 'announcement')),
      read INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- Indexes for performance
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_menu_items_outlet ON menu_items(outlet_id);
    CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category_id);
    CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_orders_outlet ON orders(outlet_id);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);
    CREATE INDEX IF NOT EXISTS idx_reservations_table ON table_reservations(table_id, reservation_date);
    CREATE INDEX IF NOT EXISTS idx_reviews_outlet ON reviews(outlet_id);
  `);

  // Record migration v1.0.0
  const existingMigration = db.prepare('SELECT id FROM schema_migrations WHERE version = ?').get('v1.0.0');
  if (!existingMigration) {
    db.prepare('INSERT INTO schema_migrations (version, description) VALUES (?, ?)').run(
      'v1.0.0',
      'Initial relational schema for BYTE Campus Food OS with Campuses, Outlets, Users, Orders, Menus, Tables, and Reviews.'
    );
  }

  seedInitialData();
}

function seedInitialData() {
  const userCount = (db.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
  if (userCount > 0) {
    return; // Already seeded
  }

  console.log('[BYTE DB] Seeding initial DJSCE Campus and Relational entities...');

  const insertCampus = db.prepare(`
    INSERT INTO campuses (id, name, location, campus_code, status)
    VALUES (1, 'Dwarkadas J. Sanghvi College of Engineering', 'Vile Parle West, Mumbai, MH 400056', 'DJSCE', 'active')
  `);
  insertCampus.run();

  // Salted hashes with bcrypt
  const salt = bcrypt.genSaltSync(10);
  const adminPass = bcrypt.hashSync('ByteAdmin123!', salt);
  const vendorPass = bcrypt.hashSync('ByteVendor123!', salt);
  const studentPass = bcrypt.hashSync('ByteStudent123!', salt);

  const insertUser = db.prepare(`
    INSERT INTO users (id, full_name, email, phone, password_hash, campus_id, user_category, operational_role, account_status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
  `);

  insertUser.run(1, 'BYTE Administrator', 'admin@example.com', '+91 98200 11001', adminPass, 'DJSCE-ADM-001', 'Non-teaching staff', 'Admin');
  insertUser.run(2, 'Central Canteen Vendor', 'vendor@example.com', '+91 98200 11002', vendorPass, 'DJSCE-VND-001', 'Non-teaching staff', 'Vendor');
  insertUser.run(3, 'South Indian Corner Vendor', 'vendor.tiffin@example.com', '+91 98200 11003', vendorPass, 'DJSCE-VND-002', 'Non-teaching staff', 'Vendor');
  insertUser.run(4, 'Beverage & Snack Station Vendor', 'vendor.chai@example.com', '+91 98200 11004', vendorPass, 'DJSCE-VND-003', 'Non-teaching staff', 'Vendor');
  insertUser.run(5, 'KEERTHI', 'student@example.com', '+91 98200 11005', studentPass, 'DJSCE-2024-CS089', 'Student', 'User');
  insertUser.run(6, 'Prof. Arvind Kulkarni', 'faculty@example.com', '+91 98200 11006', studentPass, 'DJSCE-FAC-044', 'Faculty', 'User');

  const insertOutlet = db.prepare(`
    INSERT INTO outlets (id, campus_id, outlet_name, slug, description, location, opening_time, closing_time, outlet_status, crowd_level, avg_wait_min, vendor_owner_id)
    VALUES (?, 1, ?, ?, ?, ?, '07:30', '20:30', 'active', ?, ?, ?)
  `);

  insertOutlet.run(1, 'Central Canteen', 'central-canteen', 'Everyday comfort meals, fresh tiffin, and live chaat.', 'Ground Floor · Main Building', 'MODERATE', 12, 2);
  insertOutlet.run(2, 'South Indian Corner', 'south-indian-corner', 'Crisp dosas, idlis, vadas & filter coffee.', 'Food Court · North Wing', 'LOW', 7, 3);
  insertOutlet.run(3, 'Beverage & Snack Station', 'beverage-station', 'Cutting chai, cold coffee, sandwiches, and bakery treats.', 'Library Quadrangle', 'HIGH', 15, 4);

  const insertStaff = db.prepare(`
    INSERT INTO outlet_staff (outlet_id, user_id, staff_role, status)
    VALUES (?, ?, 'vendor', 'active')
  `);
  insertStaff.run(1, 2);
  insertStaff.run(2, 3);
  insertStaff.run(3, 4);

  const insertCategory = db.prepare(`
    INSERT INTO menu_categories (id, outlet_id, category_name, description, display_order, is_active)
    VALUES (?, ?, ?, ?, ?, 1)
  `);

  insertCategory.run(1, 1, 'Popular', 'Campus most loved staples', 1);
  insertCategory.run(2, 1, 'Mains & Meals', 'Substantial hot meal combos', 2);
  insertCategory.run(3, 1, 'Quick Snacks', 'Fast bites between lectures', 3);
  insertCategory.run(4, 2, 'Breakfast & Tiffin', 'Authentic fresh South Indian morning & evening meals', 1);
  insertCategory.run(5, 2, 'Combos', 'Value packed tiffin platters', 2);
  insertCategory.run(6, 3, 'Hot & Cold Brews', 'Chai, artisanal cold coffees, and shakes', 1);
  insertCategory.run(7, 3, 'Bites & Bakery', 'Cookies, puffs, and quick munchies', 2);

  // Photos
  const MASALA_DOSA_IMG = "/src/assets/images/masala_dosa_crisp_1793399350138.jpg";
  const PAV_BHAJI_IMG = "/src/assets/images/mumbai_pav_bhaji_1793399335022.jpg";
  const VADA_PAV_IMG = "/src/assets/images/vada_pav_warm_1793399366364.jpg";
  const PANEER_BUTTER_IMG = "/src/assets/images/paneer_butter_warm_1793399310315.jpg";
  const BIRYANI_IMG = "/src/assets/images/chicken_dum_biryani_1793399380544.jpg";
  const CHOLE_BHATURE_IMG = "/src/assets/images/chole_bhature_warm_1793399396220.jpg";
  const VEG_THALI_IMG = "/src/assets/images/indian_veg_thali_1793399411006.jpg";
  const COLD_COFFEE_IMG = "/src/assets/images/chilled_cold_coffee_1793399425344.jpg";
  const CUTTING_CHAI_IMG = "/src/assets/images/cutting_chai_warm_1793399440168.jpg";

  const insertItem = db.prepare(`
    INSERT INTO menu_items (id, outlet_id, category_id, item_name, description, price, image_url, food_type, dietary_tags, allergens, preparation_time, availability_status, stock_quantity, display_order, rating, is_popular, is_active)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, ?, ?, ?, 1)
  `);

  insertItem.run(1, 1, 1, 'Mumbai Pav Bhaji', 'Slow-simmered spiced bhaji with melting butter slab, served with buttered toasted pav & fresh chopped onions.', 80, PAV_BHAJI_IMG, 'veg', '["Butter", "Spicy", "Comfort"]', '["Dairy", "Gluten"]', 8, 45, 1, 4.9, 1);
  insertItem.run(2, 1, 1, 'Authentic Mumbai Vada Pav', 'The classic DJSCE campus fuel: Spiced golden batata vada in pav, layered with red garlic chutney & fried chilli.', 25, VADA_PAV_IMG, 'veg', '["Iconic", "Street Food"]', '["Gluten"]', 4, 60, 2, 4.8, 1);
  insertItem.run(3, 1, 2, 'Paneer Butter Masala', 'Silky tomato-cashew makhani gravy with tender cottage cheese, fresh cream swirl & warm butter tandoori naan.', 120, PANEER_BUTTER_IMG, 'veg', '["North Indian", "Rich"]', '["Dairy", "Nuts"]', 12, 30, 3, 4.9, 1);
  insertItem.run(4, 1, 2, 'Campus Special Veg Thali', 'Complete student meal: 2 Phulkas, Paneer Subzi, Dal Tadka, Steamed Jeera Rice, Curd & Gulab Jamun.', 90, VEG_THALI_IMG, 'jain', '["Full Meal", "Balanced", "Jain Friendly"]', '["Dairy", "Gluten"]', 12, 40, 4, 4.7, 0);
  insertItem.run(5, 1, 3, 'Grilled Paneer Wrap', 'Spiced paneer tikka slices with crunchy bell peppers, mint yogurt dressing and pickled onions rolled in flatbread.', 80, PANEER_BUTTER_IMG, 'veg', '["Quick Bite"]', '["Dairy", "Gluten"]', 7, 25, 5, 4.6, 0);
  insertItem.run(6, 2, 4, 'Mysore Masala Dosa', 'Crisp roasted fermented rice crepe smeared with spicy red chutney, stuffed with spiced potato bhaji, served with coconut chutney & sambar.', 70, MASALA_DOSA_IMG, 'jain', '["Crisp", "South Indian", "Jain Available"]', '["Mustard"]', 10, 50, 1, 5.0, 1);
  insertItem.run(7, 2, 4, 'Steamed Idli Sambar (2 Pcs)', 'Pillow-soft steamed rice & lentil cakes dipped in hot aromatic drumstick sambar with tempered coconut chutney.', 45, MASALA_DOSA_IMG, 'jain', '["Steamed", "Healthy"]', '["Mustard"]', 5, 40, 2, 4.7, 0);
  insertItem.run(8, 2, 5, 'South Indian Tiffin Combo', '1 Mini Masala Dosa + 1 Steamed Idli + 1 Medu Vada with hot filter coffee.', 110, MASALA_DOSA_IMG, 'veg', '["Combo", "Best Value"]', '["Dairy", "Mustard"]', 12, 20, 3, 4.9, 1);
  insertItem.run(9, 3, 6, 'Special Cutting Chai', 'Double cardamom, crushed ginger, boiled strong Assam CTC tea with thick boiled milk.', 15, CUTTING_CHAI_IMG, 'jain', '["Hot Brew", "All Time Fav"]', '["Dairy"]', 3, 120, 1, 4.9, 1);
  insertItem.run(10, 3, 6, 'Chilled Cold Coffee with Ice Cream', 'Thick espresso blitz with milk and ice, topped with a scoop of vanilla ice cream & cocoa dusting.', 60, COLD_COFFEE_IMG, 'jain', '["Chilled", "Dessert Drink"]', '["Dairy"]', 5, 35, 2, 4.8, 1);
  insertItem.run(11, 1, 2, 'Chicken Dum Biryani', 'Fragrant basmati rice layered with marinated chicken, saffron, fried onions, and served with cucumber raita.', 120, BIRYANI_IMG, 'non_veg', '["Hyderabadi", "Fragrant"]', '["Dairy"]', 15, 0, 6, 4.8, 1);
  insertItem.run(12, 1, 2, 'Amritsari Chole Bhature', 'Two huge puffed golden bhaturas served with spicy dark Punjabi chole, pickle and onion rings.', 90, CHOLE_BHATURE_IMG, 'veg', '["North Indian", "Weekend Special"]', '["Gluten"]', 12, 30, 7, 4.8, 1);

  // Tables
  const insertTable = db.prepare(`
    INSERT INTO outlet_tables (id, outlet_id, table_number, capacity, status, location, reserved_by_user_id, reserved_by_name, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertTable.run(1, 1, 'T-01', 4, 'available', 'Main Hall · Window Side', null, null, null);
  insertTable.run(2, 1, 'T-02', 4, 'occupied', 'Main Hall · Central', null, null, null);
  insertTable.run(3, 1, 'T-03', 2, 'available', 'Main Hall · Quick Nook', null, null, null);
  insertTable.run(4, 1, 'T-04', 6, 'reserved', 'Booth A · Faculty Corner', 6, 'Prof. Arvind Kulkarni', '14:45');
  insertTable.run(5, 1, 'T-05', 4, 'available', 'Courtyard Veranda', null, null, null);
  insertTable.run(6, 1, 'T-06', 4, 'occupied', 'Courtyard Veranda', null, null, null);
  insertTable.run(7, 2, 'T-07', 2, 'available', 'High Top · Express Bar', null, null, null);
  insertTable.run(8, 2, 'T-08', 6, 'available', 'Booth B · Study Group', null, null, null);
  insertTable.run(9, 2, 'T-09', 4, 'occupied', 'South Terrace', null, null, null);
  insertTable.run(10, 2, 'T-10', 4, 'reserved', 'South Terrace', null, 'Robotics Club', '15:00');
  insertTable.run(11, 3, 'T-11', 2, 'available', 'Library Exit Zone', null, null, null);
  insertTable.run(12, 3, 'T-12', 6, 'available', 'Booth C · Lounge Area', null, null, null);

  // Seed Orders
  const insertOrder = db.prepare(`
    INSERT INTO orders (id, order_number, idempotency_key, user_id, outlet_id, subtotal, taxes, discounts, total_amount, payment_status, order_status, pickup_counter, pickup_type, scheduled_time, pickup_token, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, 'immediate', null, ?, datetime('now', ?))
  `);

  const insertOrderItem = db.prepare(`
    INSERT INTO order_items (order_id, menu_item_id, item_name_snapshot, unit_price_snapshot, quantity, item_total)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const insertPayment = db.prepare(`
    INSERT INTO payments (order_id, payment_provider, payment_reference, amount, payment_method, payment_status)
    VALUES (?, 'SANDBOX_UPI', ?, ?, 'upi', 'COMPLETED')
  `);

  insertOrder.run(1001, 'B1234', 'seed-order-1', 5, 1, 105, 105, 'SANDBOX_SUCCESS', 'PREPARING', 'COUNTER 02', 'TOKEN-B1234', '-6 minutes');
  insertOrderItem.run(1001, 1, 'Mumbai Pav Bhaji', 80, 1, 80);
  insertOrderItem.run(1001, 2, 'Authentic Mumbai Vada Pav', 25, 1, 25);
  insertPayment.run(1001, 'PAY-UPI-1001-SANDBOX', 105);

  insertOrder.run(1002, 'B1198', 'seed-order-2', 5, 2, 70, 70, 'SANDBOX_SUCCESS', 'COMPLETED', 'COUNTER 01', 'TOKEN-B1198', '-2 hours');
  insertOrderItem.run(1002, 6, 'Mysore Masala Dosa', 70, 1, 70);
  insertPayment.run(1002, 'PAY-UPI-1002-SANDBOX', 70);

  insertOrder.run(1003, 'B1142', 'seed-order-3', 5, 3, 75, 75, 'SANDBOX_SUCCESS', 'COMPLETED', 'EXPRESS WINDOW', 'TOKEN-B1142', '-1 day');
  insertOrderItem.run(1003, 10, 'Chilled Cold Coffee with Ice Cream', 60, 1, 60);
  insertOrderItem.run(1003, 9, 'Special Cutting Chai', 15, 1, 15);
  insertPayment.run(1003, 'PAY-UPI-1003-SANDBOX', 75);

  // Seed Notifications
  const insertNotice = db.prepare(`
    INSERT INTO notifications (user_id, title, body, type, read, created_at)
    VALUES (?, ?, ?, ?, ?, datetime('now', ?))
  `);
  insertNotice.run(5, 'Order In Kitchen', 'Order #B1234 is currently being prepared at Central Canteen.', 'order', 0, '-4 minutes');
  insertNotice.run(5, 'Campus Lunch Rush Alert', 'Central Canteen is experiencing moderate rush. Average wait time is ~12 min.', 'rush', 0, '-25 minutes');
  insertNotice.run(5, 'Express Pickup Active', 'Counter 02 is designated for express QR pickups today.', 'pickup', 1, '-1 hour');
  insertNotice.run(5, 'Table Reservation Reminder', 'Reserved tables expire in 15 minutes if unverified at the counter.', 'announcement', 1, '-3 hours');

  // Seed Review for Order 1002
  const insertReview = db.prepare(`
    INSERT INTO reviews (user_id, outlet_id, order_id, rating, review_text)
    VALUES (?, ?, ?, ?, ?)
  `);
  insertReview.run(5, 2, 1002, 5, 'Crisp Mysore Masala Dosa hot from the counter! Chutney was fresh.');

  console.log('[BYTE DB] Database seeding completed successfully.');
}
