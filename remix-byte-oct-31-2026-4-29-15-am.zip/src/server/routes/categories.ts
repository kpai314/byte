import { Router } from 'express';
import { db } from '../db';
import { requireVendorOrAdmin } from '../middleware/auth';

const router = Router();

// GET /api/categories?outlet_id=1
router.get('/', (req, res) => {
  const outletId = req.query.outlet_id ? parseInt(req.query.outlet_id as string, 10) : null;
  let sql = 'SELECT * FROM menu_categories WHERE is_active = 1';
  const params: any[] = [];
  if (outletId) {
    sql += ' AND outlet_id = ?';
    params.push(outletId);
  }
  sql += ' ORDER BY display_order ASC, id ASC';
  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

// POST /api/categories
router.post('/', requireVendorOrAdmin, (req, res) => {
  const { outlet_id, category_name, description, display_order } = req.body;
  if (!outlet_id || !category_name) {
    res.status(400).json({ detail: "outlet_id and category_name are required." });
    return;
  }
  try {
    const info = db.prepare(`
      INSERT INTO menu_categories (outlet_id, category_name, description, display_order, is_active)
      VALUES (?, ?, ?, ?, 1)
    `).run(outlet_id, category_name, description || '', display_order || 0);
    const created = db.prepare('SELECT * FROM menu_categories WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json(created);
  } catch (err: any) {
    res.status(400).json({ detail: err.message || "Failed to create category." });
  }
});

// PATCH /api/categories/:id
router.patch('/:id', requireVendorOrAdmin, (req, res) => {
  const { category_name, description, display_order, is_active } = req.body;
  const updates: string[] = [];
  const params: any[] = [];

  if (category_name !== undefined) { updates.push('category_name = ?'); params.push(category_name); }
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (display_order !== undefined) { updates.push('display_order = ?'); params.push(display_order); }
  if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }

  if (updates.length === 0) {
    res.status(400).json({ detail: "No updates provided." });
    return;
  }

  params.push(req.params.id);
  db.prepare(`UPDATE menu_categories SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const updated = db.prepare('SELECT * FROM menu_categories WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// DELETE /api/categories/:id (soft delete)
router.delete('/:id', requireVendorOrAdmin, (req, res) => {
  db.prepare('UPDATE menu_categories SET is_active = 0 WHERE id = ?').run(req.params.id);
  res.json({ message: "Category deactivated." });
});

export default router;
