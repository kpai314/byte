import { Router } from 'express';
import { db } from '../db';
import { requireAuth } from '../middleware/auth';

const router = Router();

// GET /api/reservations/tables (also /api/tables and /api/v1/tables)
router.get('/tables', (_req, res) => {
  const tables = db.prepare(`
    SELECT t.*, o.outlet_name
    FROM outlet_tables t
    JOIN outlets o ON t.outlet_id = o.id
    ORDER BY t.id ASC
  `).all();

  res.json(tables.map((t: any) => ({
    id: t.id,
    outlet_id: t.outlet_id,
    outlet_name: t.outlet_name,
    table_number: t.table_number,
    capacity: t.capacity,
    status: t.status,
    location: t.location,
    reserved_by: t.reserved_by_name,
    reserved_by_name: t.reserved_by_name,
    expires_at: t.expires_at,
  })));
});

// POST /api/reservations/tables/:tableId/reserve (also /api/v1/tables/:tableId/reserve)
router.post('/tables/:tableId/reserve', requireAuth, (req, res) => {
  const user = req.user!;
  const tableId = parseInt(req.params.tableId, 10);
  const durationMin = Number(req.body.duration_minutes) || 15;
  const partySize = Number(req.body.party_size) || 2;

  // Transaction for reservation conflict prevention
  const reserveTx = db.transaction(() => {
    const table = db.prepare('SELECT * FROM outlet_tables WHERE id = ?').get(tableId) as any;
    if (!table) {
      throw new Error("Table not found");
    }

    // Check if table is currently available
    if (table.status !== 'available') {
      throw new Error(`Table ${table.table_number} is currently ${table.status}. Please select another table.`);
    }

    const now = new Date();
    const expiryDate = new Date(now.getTime() + durationMin * 60 * 1000);
    const timeString = expiryDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const todayStr = now.toISOString().split('T')[0];
    const startTimeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Prevent conflicting reservations for same table & date overlapping
    const conflict = db.prepare(`
      SELECT id FROM table_reservations
      WHERE table_id = ? AND reservation_date = ? AND reservation_status = 'active'
    `).get(tableId, todayStr);

    if (conflict) {
      throw new Error(`Table ${table.table_number} already has an active reservation slot.`);
    }

    const reservationNumber = `RES-T${table.table_number}-${Date.now().toString().slice(-4)}`;

    // Update table status
    db.prepare(`
      UPDATE outlet_tables
      SET status = 'reserved', reserved_by_user_id = ?, reserved_by_name = ?, expires_at = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(user.id, user.full_name, timeString, tableId);

    // Insert reservation record
    db.prepare(`
      INSERT INTO table_reservations (
        reservation_number, user_id, outlet_id, table_id,
        reservation_date, start_time, end_time, party_size, reservation_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
    `).run(
      reservationNumber,
      user.id,
      table.outlet_id,
      tableId,
      todayStr,
      startTimeStr,
      timeString,
      partySize
    );

    // Insert notification
    db.prepare(`
      INSERT INTO notifications (user_id, title, body, type, read)
      VALUES (?, ?, ?, 'announcement', 0)
    `).run(
      user.id,
      `Table ${table.table_number} Reserved`,
      `Your table is held until ${timeString} (${durationMin} min). Please verify at counter upon arrival.`
    );

    const updatedTable = db.prepare('SELECT * FROM outlet_tables WHERE id = ?').get(tableId) as any;
    return {
      success: true,
      reservation_number: reservationNumber,
      table: {
        id: updatedTable.id,
        table_number: updatedTable.table_number,
        capacity: updatedTable.capacity,
        status: updatedTable.status,
        location: updatedTable.location,
        reserved_by: updatedTable.reserved_by_name,
        expires_at: updatedTable.expires_at,
      },
    };
  });

  try {
    const result = reserveTx();
    res.json(result);
  } catch (err: any) {
    res.status(409).json({ detail: err.message || "Failed to reserve table." });
  }
});

// POST /api/reservations/tables/:tableId/cancel (also /api/v1/tables/:tableId/cancel)
router.post('/tables/:tableId/cancel', requireAuth, (req, res) => {
  const user = req.user!;
  const tableId = parseInt(req.params.tableId, 10);

  const table = db.prepare('SELECT * FROM outlet_tables WHERE id = ?').get(tableId) as any;
  if (!table) {
    res.status(404).json({ detail: "Table not found" });
    return;
  }

  // Release table
  db.prepare(`
    UPDATE outlet_tables
    SET status = 'available', reserved_by_user_id = NULL, reserved_by_name = NULL, expires_at = NULL, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(tableId);

  // Mark reservation cancelled
  db.prepare(`
    UPDATE table_reservations
    SET reservation_status = 'cancelled', updated_at = CURRENT_TIMESTAMP
    WHERE table_id = ? AND reservation_status = 'active'
  `).run(tableId);

  const updated = db.prepare('SELECT * FROM outlet_tables WHERE id = ?').get(tableId) as any;

  res.json({
    success: true,
    table: {
      id: updated.id,
      table_number: updated.table_number,
      capacity: updated.capacity,
      status: updated.status,
      location: updated.location,
    },
  });
});

// GET /api/reservations/mine
router.get('/mine', requireAuth, (req, res) => {
  const user = req.user!;
  const list = db.prepare(`
    SELECT r.*, t.table_number, t.location, o.outlet_name
    FROM table_reservations r
    JOIN outlet_tables t ON r.table_id = t.id
    JOIN outlets o ON r.outlet_id = o.id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
  `).all(user.id);
  res.json(list);
});

export default router;
