import { Router } from 'express';
import { db } from '../db';
import { requireVendorOrAdmin } from '../middleware/auth';

const router = Router();

// GET /api/vendor/outlets (also /api/v1/vendor/outlets)
router.get('/outlets', requireVendorOrAdmin, (req, res) => {
  const user = req.user!;
  if (user.operational_role === 'Admin') {
    const allOutlets = db.prepare('SELECT * FROM outlets ORDER BY id ASC').all();
    res.json(allOutlets);
    return;
  }

  // Get outlets where user is owner or staff
  const userOutlets = db.prepare(`
    SELECT DISTINCT o.*
    FROM outlets o
    LEFT JOIN outlet_staff s ON o.id = s.outlet_id
    WHERE o.vendor_owner_id = ? OR (s.user_id = ? AND s.status = 'active')
    ORDER BY o.id ASC
  `).all(user.id, user.id);

  res.json(userOutlets);
});

// GET /api/vendor/orders (also /api/v1/vendor/orders)
router.get('/orders', requireVendorOrAdmin, (req, res) => {
  const user = req.user!;
  let orders: any[];

  if (user.operational_role === 'Admin') {
    orders = db.prepare(`
      SELECT o.*, out.outlet_name
      FROM orders o
      JOIN outlets out ON o.outlet_id = out.id
      ORDER BY o.created_at DESC
      LIMIT 100
    `).all();
  } else {
    orders = db.prepare(`
      SELECT DISTINCT o.*, out.outlet_name
      FROM orders o
      JOIN outlets out ON o.outlet_id = out.id
      LEFT JOIN outlet_staff s ON out.id = s.outlet_id
      WHERE out.vendor_owner_id = ? OR (s.user_id = ? AND s.status = 'active')
      ORDER BY o.created_at DESC
      LIMIT 100
    `).all(user.id, user.id);
  }

  const result = orders.map(o => {
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id);
    return {
      id: o.id,
      order_number: o.order_number,
      outlet_id: o.outlet_id,
      outlet_name: o.outlet_name,
      pickup_counter: o.pickup_counter,
      status: o.order_status,
      order_status: o.order_status,
      total: o.total_amount,
      total_amount: o.total_amount,
      created_at: o.created_at,
      items: items.map((i: any) => ({
        id: i.id,
        name: i.item_name_snapshot,
        quantity: i.quantity,
        unit_price: i.unit_price_snapshot,
        line_total: i.item_total,
      })),
    };
  });

  res.json(result);
});

// PATCH /api/vendor/orders/:orderId/status (also /api/v1/vendor/orders/:orderId/status)
router.patch('/orders/:orderId/status', requireVendorOrAdmin, (req, res) => {
  const orderId = parseInt(req.params.orderId, 10);
  const nextStatus = req.body.status;
  const allowed = ["PLACED", "PREPARING", "READY", "COMPLETED", "CANCELLED"];

  if (!allowed.includes(nextStatus)) {
    res.status(400).json({ detail: `Invalid order status '${nextStatus}'. Must be one of: ${allowed.join(', ')}` });
    return;
  }

  const order = db.prepare('SELECT o.*, out.outlet_name FROM orders o JOIN outlets out ON o.outlet_id = out.id WHERE o.id = ?').get(orderId) as any;
  if (!order) {
    res.status(404).json({ detail: "Order not found." });
    return;
  }

  // Valid order state machine transitions check
  const current = order.order_status;
  if (current === 'COMPLETED' || current === 'CANCELLED') {
    res.status(400).json({ detail: `Order is already ${current} and cannot be altered.` });
    return;
  }

  db.prepare(`
    UPDATE orders SET order_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(nextStatus, orderId);

  // If status is READY, dispatch pickup notification
  if (nextStatus === 'READY') {
    db.prepare(`
      INSERT INTO notifications (user_id, title, body, type, read)
      VALUES (?, ?, ?, 'pickup', 0)
    `).run(
      order.user_id,
      `Order #${order.order_number} Ready for Pickup!`,
      `Your food is ready at ${order.pickup_counter}. Show your QR token.`
    );
  } else if (nextStatus === 'COMPLETED') {
    db.prepare(`
      INSERT INTO notifications (user_id, title, body, type, read)
      VALUES (?, ?, ?, 'order', 0)
    `).run(
      order.user_id,
      `Order #${order.order_number} Completed`,
      `Thank you for dining with BYTE at ${order.outlet_name}! You can now share a review.`
    );
  }

  res.json({ id: order.id, status: nextStatus, order_status: nextStatus });
});

// POST /api/vendor/outlets/:outletId/items (also /api/v1/vendor/outlets/:outletId/items)
router.post('/outlets/:outletId/items', requireVendorOrAdmin, (req, res) => {
  const outletId = parseInt(req.params.outletId, 10);
  const {
    category_id,
    name,
    item_name,
    description,
    price,
    image_url,
    prep_minutes,
    preparation_time,
    dietary_type,
    food_type,
    is_jain,
  } = req.body;

  const title = item_name || name || 'Campus Special';
  const type = food_type || (is_jain ? 'jain' : (dietary_type || 'veg'));
  const prep = Number(preparation_time || prep_minutes || 10);
  const cost = Number(price) || 50;

  const info = db.prepare(`
    INSERT INTO menu_items (
      outlet_id, category_id, item_name, description, price, image_url,
      food_type, preparation_time, availability_status, stock_quantity,
      display_order, rating, is_popular, is_active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', 30, 0, 4.8, 0, 1)
  `).run(
    outletId,
    category_id || 1,
    title,
    description || 'Made fresh at the campus counter.',
    cost,
    image_url || '/src/assets/images/mumbai_pav_bhaji_1793399335022.jpg',
    type,
    prep
  );

  const created = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(info.lastInsertRowid) as any;
  res.status(201).json({
    id: created.id,
    outlet_id: created.outlet_id,
    category_id: created.category_id,
    name: created.item_name,
    description: created.description,
    price: created.price,
    image_url: created.image_url,
    prep_minutes: created.preparation_time,
    dietary_type: created.food_type,
    is_jain: created.food_type === 'jain',
    is_available: created.availability_status === 'available',
    available_quantity: created.stock_quantity,
    rating: created.rating,
  });
});

// PATCH /api/vendor/items/:itemId/availability (also /api/v1/vendor/items/:itemId/availability)
router.patch('/items/:itemId/availability', requireVendorOrAdmin, (req, res) => {
  const itemId = parseInt(req.params.itemId, 10);
  const isAvailable = Boolean(req.body.is_available);
  const status = isAvailable ? 'available' : 'sold_out';

  db.prepare(`
    UPDATE menu_items SET availability_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(status, itemId);

  res.json({ id: itemId, is_available: isAvailable, availability_status: status });
});

export default router;
