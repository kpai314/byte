import { Router } from 'express';
import { db } from '../db';
import { requireVendorOrAdmin } from '../middleware/auth';

const router = Router();

// GET /api/media
router.get('/', (req, res) => {
  const outletId = req.query.outlet_id ? parseInt(req.query.outlet_id as string, 10) : null;
  let sql = 'SELECT * FROM media_assets';
  const params: any[] = [];
  if (outletId) {
    sql += ' WHERE outlet_id = ?';
    params.push(outletId);
  }
  sql += ' ORDER BY created_at DESC';
  const assets = db.prepare(sql).all(...params);
  res.json(assets);
});

// POST /api/media (Register media asset metadata)
router.post('/', requireVendorOrAdmin, (req, res) => {
  const { outlet_id, media_type, media_url, thumbnail_url, alt_text, title, duration_seconds } = req.body;
  if (!media_type || !media_url) {
    res.status(400).json({ detail: "media_type and media_url are required." });
    return;
  }

  const info = db.prepare(`
    INSERT INTO media_assets (outlet_id, media_type, media_url, thumbnail_url, alt_text, title, duration_seconds)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    outlet_id || null,
    media_type,
    media_url,
    thumbnail_url || null,
    alt_text || '',
    title || '',
    duration_seconds || null
  );

  const created = db.prepare('SELECT * FROM media_assets WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(created);
});

export default router;
