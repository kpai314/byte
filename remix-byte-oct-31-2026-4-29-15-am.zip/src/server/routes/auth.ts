import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { db } from '../db';
import { createSession, deleteSession, requireAuth, requireAdmin } from '../middleware/auth';

const router = Router();

// POST /api/auth/login (also /api/v1/auth/login)
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ detail: "Email and password are required." });
    return;
  }

  const user = db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?)').get(email) as any;
  if (!user) {
    res.status(401).json({ detail: "Invalid email or password." });
    return;
  }

  const isMatch = bcrypt.compareSync(password, user.password_hash);
  if (!isMatch) {
    res.status(401).json({ detail: "Invalid email or password." });
    return;
  }

  if (user.account_status !== 'active') {
    res.status(403).json({ detail: `Account is ${user.account_status}. Please contact campus admin.` });
    return;
  }

  const sessionToken = createSession(user.id);

  // Set HTTP-only session cookie
  res.cookie('byte_session', sessionToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 14 * 24 * 60 * 60 * 1000,
  });

  res.json({
    id: user.id,
    name: user.full_name,
    full_name: user.full_name,
    email: user.email,
    phone: user.phone,
    role: user.operational_role.toLowerCase().replace(' ', '_'),
    operational_role: user.operational_role,
    user_category: user.user_category,
    user_type: user.user_category.toLowerCase(),
    campus_id: user.campus_id,
    token: sessionToken,
  });
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  const token = req.cookies?.byte_session || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);
  if (token) {
    deleteSession(token);
  }
  res.clearCookie('byte_session');
  res.json({ ok: true, message: "Logged out successfully" });
});

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  const u = req.user!;
  res.json({
    id: u.id,
    name: u.full_name,
    full_name: u.full_name,
    email: u.email,
    phone: u.phone,
    role: u.operational_role.toLowerCase().replace(' ', '_'),
    operational_role: u.operational_role,
    user_category: u.user_category,
    user_type: u.user_category.toLowerCase(),
    campus_id: u.campus_id,
    account_status: u.account_status,
  });
});

// POST /api/auth/register (User signup with verification)
router.post('/register', (req, res) => {
  const { full_name, email, password, phone, campus_id, user_category } = req.body;

  if (!full_name || !email || !password) {
    res.status(400).json({ detail: "Full name, email, and password are required." });
    return;
  }

  const existing = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?)').get(email);
  if (existing) {
    res.status(409).json({ detail: "An account with this email address already exists." });
    return;
  }

  const validCategories = ['Student', 'Faculty', 'Non-teaching staff'];
  const category = validCategories.includes(user_category) ? user_category : 'Student';

  const password_hash = bcrypt.hashSync(password, 10);

  const insert = db.prepare(`
    INSERT INTO users (full_name, email, phone, password_hash, campus_id, user_category, operational_role, account_status)
    VALUES (?, ?, ?, ?, ?, ?, 'User', 'active')
  `);

  const info = insert.run(full_name, email, phone || null, password_hash, campus_id || 'DJSCE-2026-REG', category);
  const newUserId = info.lastInsertRowid as number;

  const sessionToken = createSession(newUserId);
  res.cookie('byte_session', sessionToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 14 * 24 * 60 * 60 * 1000,
  });

  res.status(201).json({
    id: newUserId,
    name: full_name,
    full_name,
    email,
    role: 'user',
    operational_role: 'User',
    user_category: category,
    campus_id: campus_id || 'DJSCE-2026-REG',
    token: sessionToken,
  });
});

// POST /api/auth/password-reset-request
router.post('/password-reset-request', (req, res) => {
  const { email } = req.body;
  if (!email) {
    res.status(400).json({ detail: "Email required." });
    return;
  }

  const user = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?)').get(email) as any;
  if (!user) {
    // Return standard generic success to prevent email enumeration
    res.json({ message: "If an account exists with this email, a reset token has been issued." });
    return;
  }

  const token = crypto.randomBytes(20).toString('hex');
  const expires = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hour

  db.prepare(`
    UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?
  `).run(token, expires, user.id);

  res.json({
    message: "Password reset token generated successfully.",
    reset_token: token, // In demo sandbox returned directly; in production sent via email
  });
});

// POST /api/auth/password-reset-confirm
router.post('/password-reset-confirm', (req, res) => {
  const { token, new_password } = req.body;
  if (!token || !new_password) {
    res.status(400).json({ detail: "Token and new password required." });
    return;
  }

  const user = db.prepare(`
    SELECT id FROM users
    WHERE reset_token = ? AND reset_token_expires > datetime('now')
  `).get(token) as any;

  if (!user) {
    res.status(400).json({ detail: "Invalid or expired password reset token." });
    return;
  }

  const password_hash = bcrypt.hashSync(new_password, 10);
  db.prepare(`
    UPDATE users
    SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(password_hash, user.id);

  res.json({ message: "Password updated successfully. You may now log in." });
});

// POST /api/auth/activate (Account activation)
router.post('/activate/:userId', requireAdmin, (req, res) => {
  const userId = parseInt(req.params.userId, 10);
  db.prepare(`
    UPDATE users SET account_status = 'active', updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(userId);
  res.json({ message: "User account activated successfully." });
});

export default router;
