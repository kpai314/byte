import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db';
import { requireAdmin } from '../middleware/auth';

const router = Router();

// GET /api/admin/analytics (also /api/v1/admin/analytics)
router.get('/analytics', requireAdmin, (_req, res) => {
  const totalOrders = (db.prepare('SELECT COUNT(*) as c FROM orders').get() as any).c;
  const activeUsers = (db.prepare("SELECT COUNT(*) as c FROM users WHERE account_status = 'active'").get() as any).c;
  const totalOutlets = (db.prepare('SELECT COUNT(*) as c FROM outlets').get() as any).c;
  const activeMenuItems = (db.prepare('SELECT COUNT(*) as c FROM menu_items WHERE is_active = 1').get() as any).c;
  const revenueResult = (db.prepare("SELECT SUM(total_amount) as s FROM orders WHERE order_status != 'CANCELLED'").get() as any).s || 0;
  const avgPrepResult = (db.prepare("SELECT AVG(preparation_time) as a FROM menu_items WHERE is_active = 1").get() as any).a || 10;
  const pendingOrders = (db.prepare("SELECT COUNT(*) as c FROM orders WHERE order_status IN ('PLACED', 'PREPARING')").get() as any).c;

  const users = db.prepare(`
    SELECT id, full_name as name, email, phone, campus_id, user_category, operational_role as role, account_status, created_at
    FROM users
    ORDER BY id ASC
  `).all();

  res.json({
    total_orders: totalOrders,
    active_users: activeUsers,
    total_outlets: totalOutlets,
    active_menu_items: activeMenuItems,
    total_revenue_inr: revenueResult,
    pending_orders: pendingOrders,
    average_prep_time_min: Number(avgPrepResult.toFixed(1)),
    peak_ordering_window: "12:45 PM – 01:30 PM",
    users,
  });
});

// GET /api/admin/users
router.get('/users', requireAdmin, (_req, res) => {
  const users = db.prepare(`
    SELECT id, full_name, email, phone, campus_id, user_category, operational_role, account_status, created_at
    FROM users
    ORDER BY id ASC
  `).all();
  res.json(users);
});

// POST /api/admin/users (Admin-controlled user creation)
router.post('/users', requireAdmin, (req, res) => {
  const { full_name, email, password, phone, campus_id, user_category, operational_role } = req.body;

  if (!full_name || !email || !password) {
    res.status(400).json({ detail: "full_name, email, and password are required." });
    return;
  }

  const existing = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?)').get(email);
  if (existing) {
    res.status(409).json({ detail: "User with this email already exists." });
    return;
  }

  const validCategories = ['Student', 'Faculty', 'Non-teaching staff'];
  const validRoles = ['User', 'Admin', 'Vendor', 'Outlet staff'];

  const category = validCategories.includes(user_category) ? user_category : 'Student';
  const role = validRoles.includes(operational_role) ? operational_role : 'User';

  const hash = bcrypt.hashSync(password, 10);

  const info = db.prepare(`
    INSERT INTO users (full_name, email, phone, password_hash, campus_id, user_category, operational_role, account_status)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
  `).run(full_name, email, phone || null, hash, campus_id || 'DJSCE-2026', category, role);

  const created = db.prepare('SELECT id, full_name, email, phone, campus_id, user_category, operational_role, account_status FROM users WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(created);
});

// PATCH /api/admin/users/:id/status
router.patch('/users/:id/status', requireAdmin, (req, res) => {
  const { account_status } = req.body;
  const allowed = ['active', 'inactive', 'pending_activation'];
  if (!allowed.includes(account_status)) {
    res.status(400).json({ detail: `Invalid account status '${account_status}'.` });
    return;
  }

  db.prepare(`
    UPDATE users SET account_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(account_status, req.params.id);

  const updated = db.prepare('SELECT id, full_name, email, operational_role, account_status FROM users WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// PATCH /api/admin/users/:id/role
router.patch('/users/:id/role', requireAdmin, (req, res) => {
  const { operational_role } = req.body;
  const allowed = ['User', 'Admin', 'Vendor', 'Outlet staff'];
  if (!allowed.includes(operational_role)) {
    res.status(400).json({ detail: `Invalid role '${operational_role}'.` });
    return;
  }

  db.prepare(`
    UPDATE users SET operational_role = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(operational_role, req.params.id);

  const updated = db.prepare('SELECT id, full_name, email, operational_role, account_status FROM users WHERE id = ?').get(req.params.id);
  res.json(updated);
});

export default router;
