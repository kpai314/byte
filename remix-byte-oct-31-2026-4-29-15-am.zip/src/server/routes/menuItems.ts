import { Router } from 'express';
import { db } from '../db';
import { requireVendorOrAdmin } from '../middleware/auth';

const router = Router();

// Helper to format item to both legacy and standard fields
function formatItem(i: any) {
  return {
    id: i.id,
    outlet_id: i.outlet_id,
    outlet_name: i.outlet_name || undefined,
    category_id: i.category_id,
    category_name: i.category_name || undefined,
    name: i.item_name,
    item_name: i.item_name,
    description: i.description,
    price: i.price,
    image_url: i.image_url,
    prep_minutes: i.preparation_time,
    preparation_time: i.preparation_time,
    food_type: i.food_type,
    dietary_type: i.food_type,
    dietary_tags: typeof i.dietary_tags === 'string' ? JSON.parse(i.dietary_tags || '[]') : i.dietary_tags,
    allergens: typeof i.allergens === 'string' ? JSON.parse(i.allergens || '[]') : i.allergens,
    is_jain: i.food_type === 'jain',
    is_available: i.availability_status === 'available',
    availability_status: i.availability_status,
    available_quantity: i.stock_quantity,
    stock_quantity: i.stock_quantity,
    rating: i.rating,
    is_popular: Boolean(i.is_popular),
    is_active: Boolean(i.is_active),
    created_at: i.created_at,
    updated_at: i.updated_at,
  };
}

// GET /api/menu-items (also /api/v1/foods)
router.get('/', (req, res) => {
  const { outlet_id, category_id, food_type, search, is_available } = req.query;

  let sql = `
    SELECT m.*, o.outlet_name, c.category_name
    FROM menu_items m
    JOIN outlets o ON m.outlet_id = o.id
    JOIN menu_categories c ON m.category_id = c.id
    WHERE m.is_active = 1
  `;
  const params: any[] = [];

  if (outlet_id) {
    sql += ' AND m.outlet_id = ?';
    params.push(parseInt(outlet_id as string, 10));
  }
  if (category_id) {
    sql += ' AND m.category_id = ?';
    params.push(parseInt(category_id as string, 10));
  }
  if (food_type && food_type !== 'all') {
    sql += ' AND m.food_type = ?';
    params.push(food_type);
  }
  if (is_available !== undefined) {
    sql += ' AND m.availability_status = ?';
    params.push(is_available === 'true' ? 'available' : 'sold_out');
  }
  if (search) {
    sql += ' AND (m.item_name LIKE ? OR m.description LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  sql += ' ORDER BY m.display_order ASC, m.id ASC';

  const rows = db.prepare(sql).all(...params);
  res.json(rows.map(formatItem));
});

// GET /api/menu-items/:id
router.get('/:id', (req, res) => {
  const row = db.prepare(`
    SELECT m.*, o.outlet_name, c.category_name
    FROM menu_items m
    JOIN outlets o ON m.outlet_id = o.id
    JOIN menu_categories c ON m.category_id = c.id
    WHERE m.id = ?
  `).get(req.params.id);

  if (!row) {
    res.status(404).json({ detail: "Menu item not found." });
    return;
  }
  res.json(formatItem(row));
});

// POST /api/menu-items
router.post('/', requireVendorOrAdmin, (req, res) => {
  const {
    outlet_id,
    category_id,
    item_name,
    name,
    description,
    price,
    image_url,
    food_type,
    dietary_tags,
    allergens,
    preparation_time,
    prep_minutes,
    stock_quantity,
  } = req.body;

  const title = item_name || name;
  if (!outlet_id || !category_id || !title || price === undefined) {
    res.status(400).json({ detail: "outlet_id, category_id, item_name, and price are required." });
    return;
  }

  if (Number(price) < 0) {
    res.status(400).json({ detail: "Price cannot be negative." });
    return;
  }

  const cleanTags = Array.isArray(dietary_tags) ? JSON.stringify(dietary_tags) : (typeof dietary_tags === 'string' ? dietary_tags : '[]');
  const cleanAllergens = Array.isArray(allergens) ? JSON.stringify(allergens) : (typeof allergens === 'string' ? allergens : '[]');

  try {
    const info = db.prepare(`
      INSERT INTO menu_items (
        outlet_id, category_id, item_name, description, price, image_url,
        food_type, dietary_tags, allergens, preparation_time,
        availability_status, stock_quantity, display_order, is_active
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, 0, 1)
    `).run(
      outlet_id,
      category_id,
      title,
      description || '',
      Number(price),
      image_url || '/src/assets/images/mumbai_pav_bhaji_1793399335022.jpg',
      food_type || 'veg',
      cleanTags,
      cleanAllergens,
      Number(preparation_time || prep_minutes || 10),
      stock_quantity !== undefined ? Number(stock_quantity) : 40
    );

    const created = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json(formatItem(created));
  } catch (err: any) {
    res.status(400).json({ detail: err.message || "Failed to create menu item." });
  }
});

// PATCH /api/menu-items/:id
router.patch('/:id', requireVendorOrAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const {
    item_name,
    name,
    description,
    price,
    image_url,
    food_type,
    dietary_tags,
    allergens,
    preparation_time,
    availability_status,
    is_available,
    stock_quantity,
  } = req.body;

  const updates: string[] = [];
  const params: any[] = [];

  const title = item_name || name;
  if (title !== undefined) { updates.push('item_name = ?'); params.push(title); }
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (price !== undefined) {
    if (Number(price) < 0) {
      res.status(400).json({ detail: "Price cannot be negative." });
      return;
    }
    updates.push('price = ?'); params.push(Number(price));
  }
  if (image_url !== undefined) { updates.push('image_url = ?'); params.push(image_url); }
  if (food_type !== undefined) { updates.push('food_type = ?'); params.push(food_type); }
  if (dietary_tags !== undefined) {
    updates.push('dietary_tags = ?');
    params.push(Array.isArray(dietary_tags) ? JSON.stringify(dietary_tags) : dietary_tags);
  }
  if (allergens !== undefined) {
    updates.push('allergens = ?');
    params.push(Array.isArray(allergens) ? JSON.stringify(allergens) : allergens);
  }
  if (preparation_time !== undefined) { updates.push('preparation_time = ?'); params.push(Number(preparation_time)); }
  if (availability_status !== undefined) { updates.push('availability_status = ?'); params.push(availability_status); }
  if (is_available !== undefined) {
    updates.push('availability_status = ?');
    params.push(is_available ? 'available' : 'sold_out');
  }
  if (stock_quantity !== undefined) {
    updates.push('stock_quantity = ?');
    params.push(Number(stock_quantity));
  }

  if (updates.length === 0) {
    res.status(400).json({ detail: "No updates provided." });
    return;
  }

  updates.push('updated_at = CURRENT_TIMESTAMP');
  params.push(id);

  db.prepare(`UPDATE menu_items SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const updated = db.prepare('SELECT * FROM menu_items WHERE id = ?').get(id);
  res.json(formatItem(updated));
});

// DELETE /api/menu-items/:id (soft delete)
router.delete('/:id', requireVendorOrAdmin, (req, res) => {
  db.prepare('UPDATE menu_items SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(req.params.id);
  res.json({ message: "Menu item deactivated successfully." });
});

export default router;
