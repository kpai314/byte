import { Router } from 'express';
import { db } from '../db';
import { requireAuth } from '../middleware/auth';

const router = Router();

// POST /api/reviews
router.post('/', requireAuth, (req, res) => {
  const user = req.user!;
  const { outlet_id, order_id, rating, review_text } = req.body;

  if (!outlet_id || !order_id || !rating) {
    res.status(400).json({ detail: "outlet_id, order_id, and rating are required." });
    return;
  }

  const numRating = Number(rating);
  if (isNaN(numRating) || numRating < 1 || numRating > 5) {
    res.status(400).json({ detail: "Rating must be an integer between 1 and 5 stars." });
    return;
  }

  // Business Rule: Only permit reviews for eligible completed orders belonging to user
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(order_id) as any;
  if (!order) {
    res.status(404).json({ detail: "Order not found." });
    return;
  }

  if (order.user_id !== user.id) {
    res.status(403).json({ detail: "You can only review orders that you placed." });
    return;
  }

  if (order.order_status !== 'COMPLETED') {
    res.status(400).json({ detail: "Reviews can only be submitted for completed orders that have been picked up." });
    return;
  }

  if (order.outlet_id !== Number(outlet_id)) {
    res.status(400).json({ detail: "Order does not match the specified outlet." });
    return;
  }

  // Prevent duplicate reviews for the same order
  const existingReview = db.prepare('SELECT id FROM reviews WHERE user_id = ? AND order_id = ?').get(user.id, order_id);
  if (existingReview) {
    res.status(409).json({ detail: "A review has already been submitted for this order." });
    return;
  }

  const info = db.prepare(`
    INSERT INTO reviews (user_id, outlet_id, order_id, rating, review_text)
    VALUES (?, ?, ?, ?, ?)
  `).run(user.id, outlet_id, order_id, numRating, review_text || '');

  const newReview = db.prepare(`
    SELECT r.*, u.full_name as author_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.id = ?
  `).get(info.lastInsertRowid);

  res.status(201).json(newReview);
});

// GET /api/reviews/outlet/:outletId
router.get('/outlet/:outletId', (req, res) => {
  const outletId = parseInt(req.params.outletId, 10);
  const reviews = db.prepare(`
    SELECT r.*, u.full_name as author_name, o.order_number
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN orders o ON r.order_id = o.id
    WHERE r.outlet_id = ?
    ORDER BY r.created_at DESC
  `).all(outletId);

  const stats = db.prepare(`
    SELECT COUNT(*) as total_reviews, AVG(rating) as average_rating
    FROM reviews WHERE outlet_id = ?
  `).get(outletId) as any;

  res.json({
    total_reviews: stats?.total_reviews || 0,
    average_rating: stats?.average_rating ? Number(stats.average_rating.toFixed(1)) : 5.0,
    reviews,
  });
});

export default router;
