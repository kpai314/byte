import { Router } from 'express';
import { db } from '../db';
import { requireAuth } from '../middleware/auth';

const router = Router();

// Helper to format order response
function formatOrderResponse(order: any, items: any[]) {
  return {
    id: order.id,
    order_number: order.order_number,
    idempotency_key: order.idempotency_key,
    user_id: order.user_id,
    outlet_id: order.outlet_id,
    outlet_name: order.outlet_name,
    pickup_counter: order.pickup_counter,
    status: order.order_status,
    order_status: order.order_status,
    payment_status: order.payment_status,
    pickup_type: order.pickup_type,
    scheduled_time: order.scheduled_time,
    pickup_token: order.pickup_token,
    subtotal: order.subtotal,
    taxes: order.taxes,
    discounts: order.discounts,
    total: order.total_amount,
    total_amount: order.total_amount,
    created_at: order.created_at,
    items: items.map(i => ({
      id: i.id,
      menu_item_id: i.menu_item_id,
      food_item_id: i.menu_item_id,
      name: i.item_name_snapshot,
      item_name: i.item_name_snapshot,
      unit_price: i.unit_price_snapshot,
      quantity: i.quantity,
      item_total: i.item_total,
      line_total: i.item_total,
    })),
  };
}

// POST /api/orders/checkout (and /api/orders, /api/v1/checkout)
router.post('/checkout', requireAuth, (req, res) => {
  const user = req.user!;
  const {
    outlet_id,
    items,
    idempotency_key,
    pickup_type,
    scheduled_time,
    payment_method,
  } = req.body;

  // 1. Idempotency Check
  if (idempotency_key) {
    const existingOrder = db.prepare(`
      SELECT o.*, out.outlet_name
      FROM orders o
      JOIN outlets out ON o.outlet_id = out.id
      WHERE o.idempotency_key = ?
    `).get(idempotency_key) as any;

    if (existingOrder) {
      if (existingOrder.user_id !== user.id) {
        res.status(409).json({ detail: "Idempotency key belongs to another user request." });
        return;
      }
      const existingItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(existingOrder.id);
      res.json({
        ...formatOrderResponse(existingOrder, existingItems),
        message: "Existing order returned — idempotency preserved with no duplicate charge.",
      });
      return;
    }
  }

  // 2. Cart Items Validation
  if (!items || !Array.isArray(items) || items.length === 0) {
    res.status(400).json({ detail: "Your shopping tray is empty. Please add items to checkout." });
    return;
  }

  if (!outlet_id) {
    res.status(400).json({ detail: "An outlet must be specified for ordering." });
    return;
  }

  const outlet = db.prepare('SELECT * FROM outlets WHERE id = ? AND outlet_status = "active"').get(outlet_id) as any;
  if (!outlet) {
    res.status(404).json({ detail: "Selected campus outlet is not active or not found." });
    return;
  }

  // 3. Database Transaction for Order Creation
  const createOrderTransaction = db.transaction(() => {
    let subtotal = 0;
    const validatedItems: Array<{
      menuItem: any;
      quantity: number;
      itemTotal: number;
    }> = [];

    // Server-Side Price Recalculation & Outlet Affinity Rule Enforcement
    for (const item of items) {
      const menuItemId = item.food_item_id || item.menu_item_id || item.id;
      const quantity = Math.floor(Number(item.quantity));

      if (!menuItemId || isNaN(quantity) || quantity <= 0) {
        throw new Error(`Invalid item quantity specified for item ${menuItemId || 'unknown'}`);
      }

      // Fetch fresh, authoritative menu item data from database
      const menuItem = db.prepare(`
        SELECT * FROM menu_items
        WHERE id = ? AND is_active = 1
      `).get(menuItemId) as any;

      if (!menuItem) {
        throw new Error(`Menu item #${menuItemId} is not currently available.`);
      }

      // Rule: Cart must never combine products from multiple outlets
      if (menuItem.outlet_id !== outlet_id) {
        throw new Error(`Item "${menuItem.item_name}" belongs to a different outlet. All items in an order must be from "${outlet.outlet_name}".`);
      }

      if (menuItem.availability_status !== 'available') {
        throw new Error(`Item "${menuItem.item_name}" is currently sold out.`);
      }

      // Stock check and safe decrement
      if (menuItem.stock_quantity !== null) {
        if (menuItem.stock_quantity < quantity) {
          throw new Error(`Insufficient stock for "${menuItem.item_name}". Only ${menuItem.stock_quantity} remaining.`);
        }
        db.prepare('UPDATE menu_items SET stock_quantity = stock_quantity - ? WHERE id = ?').run(quantity, menuItem.id);
      }

      const itemTotal = menuItem.price * quantity;
      subtotal += itemTotal;

      validatedItems.push({
        menuItem,
        quantity,
        itemTotal,
      });
    }

    const taxes = 0; // Campus subsidized, no hidden tax
    const discounts = 0;
    const totalAmount = subtotal + taxes - discounts;

    // Generate unique order number and pickup token
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `B${randomSuffix}`;
    const pickupToken = `TOKEN-${orderNumber}`;
    const pickupCounter = outlet_id === 3 ? "EXPRESS WINDOW" : `COUNTER 0${outlet_id}`;

    const paymentStatus = payment_method === 'cash' ? 'CASH_AT_COUNTER' : 'SANDBOX_SUCCESS';

    // Insert Order
    const insertOrderStmt = db.prepare(`
      INSERT INTO orders (
        order_number, idempotency_key, user_id, outlet_id,
        subtotal, taxes, discounts, total_amount,
        payment_status, order_status, pickup_counter,
        pickup_type, scheduled_time, pickup_token
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PLACED', ?, ?, ?, ?)
    `);

    const orderInfo = insertOrderStmt.run(
      orderNumber,
      idempotency_key || `idemp-${Date.now()}-${randomSuffix}`,
      user.id,
      outlet_id,
      subtotal,
      taxes,
      discounts,
      totalAmount,
      paymentStatus,
      pickupCounter,
      pickup_type || 'immediate',
      scheduled_time || null,
      pickupToken
    );

    const orderId = orderInfo.lastInsertRowid as number;

    // Insert Order Items with exact snapshots
    const insertOrderItemStmt = db.prepare(`
      INSERT INTO order_items (
        order_id, menu_item_id, item_name_snapshot,
        unit_price_snapshot, quantity, item_total
      ) VALUES (?, ?, ?, ?, ?, ?)
    `);

    for (const v of validatedItems) {
      insertOrderItemStmt.run(
        orderId,
        v.menuItem.id,
        v.menuItem.item_name,
        v.menuItem.price,
        v.quantity,
        v.itemTotal
      );
    }

    // Insert Payment Record
    const paymentRef = `PAY-SANDBOX-${orderNumber}-${Date.now()}`;
    db.prepare(`
      INSERT INTO payments (
        order_id, payment_provider, payment_reference,
        amount, payment_method, payment_status
      ) VALUES (?, 'SANDBOX_UPI', ?, ?, ?, 'COMPLETED')
    `).run(orderId, paymentRef, totalAmount, payment_method === 'cash' ? 'cash' : 'upi');

    // Add in-app Notification for student
    db.prepare(`
      INSERT INTO notifications (user_id, title, body, type, read)
      VALUES (?, ?, ?, 'order', 0)
    `).run(
      user.id,
      `Order #${orderNumber} Confirmed`,
      `Placed at ${outlet.outlet_name}. Collect at ${pickupCounter} when ready.`
    );

    return { orderId, orderNumber, pickupCounter, totalAmount, paymentStatus, subtotal, pickupToken };
  });

  try {
    const result = createOrderTransaction();
    const createdOrder = db.prepare(`
      SELECT o.*, out.outlet_name
      FROM orders o
      JOIN outlets out ON o.outlet_id = out.id
      WHERE o.id = ?
    `).get(result.orderId) as any;

    const createdItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(result.orderId);

    res.status(201).json({
      ...formatOrderResponse(createdOrder, createdItems),
      message: "Sandbox campus checkout verified — no real money was collected.",
    });
  } catch (err: any) {
    res.status(400).json({ detail: err.message || "Checkout failed." });
  }
});

// GET /api/orders/mine (User's order history)
router.get('/mine', requireAuth, (req, res) => {
  const user = req.user!;
  const orders = db.prepare(`
    SELECT o.*, out.outlet_name
    FROM orders o
    JOIN outlets out ON o.outlet_id = out.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
  `).all(user.id) as any[];

  const result = orders.map(o => {
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id);
    return formatOrderResponse(o, items);
  });

  res.json(result);
});

// GET /api/orders/:id
router.get('/:id', requireAuth, (req, res) => {
  const user = req.user!;
  const order = db.prepare(`
    SELECT o.*, out.outlet_name
    FROM orders o
    JOIN outlets out ON o.outlet_id = out.id
    WHERE o.id = ?
  `).get(req.params.id) as any;

  if (!order) {
    res.status(404).json({ detail: "Order not found." });
    return;
  }

  // Authorization: user must own order or be vendor/admin
  if (order.user_id !== user.id && !['Admin', 'Vendor', 'Outlet staff'].includes(user.operational_role)) {
    res.status(403).json({ detail: "Not authorized to view this order." });
    return;
  }

  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
  res.json(formatOrderResponse(order, items));
});

// PATCH /api/orders/:id/cancel
router.patch('/:id/cancel', requireAuth, (req, res) => {
  const user = req.user!;
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id) as any;
  if (!order) {
    res.status(404).json({ detail: "Order not found." });
    return;
  }
  if (order.user_id !== user.id && user.operational_role !== 'Admin') {
    res.status(403).json({ detail: "Not authorized to cancel this order." });
    return;
  }
  if (order.order_status !== 'PLACED') {
    res.status(400).json({ detail: `Cannot cancel an order that is already ${order.order_status}.` });
    return;
  }

  db.prepare(`
    UPDATE orders SET order_status = 'CANCELLED', updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(order.id);

  res.json({ message: "Order cancelled successfully.", id: order.id, status: 'CANCELLED' });
});

export default router;
