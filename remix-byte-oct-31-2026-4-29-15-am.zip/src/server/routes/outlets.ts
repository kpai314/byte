import { Router } from 'express';
import { db } from '../db';
import { requireAdmin, requireVendorOrAdmin } from '../middleware/auth';

const router = Router();

// GET /api/outlets (also /api/v1/outlets)
router.get('/', (_req, res) => {
  const outlets = db.prepare(`
    SELECT o.*,
      (SELECT COUNT(*) FROM outlet_tables t WHERE t.outlet_id = o.id AND t.status = 'available') AS available_tables,
      (SELECT COUNT(*) FROM menu_items m WHERE m.outlet_id = o.id AND m.is_active = 1) AS total_items
    FROM outlets o
    WHERE o.outlet_status = 'active'
    ORDER BY o.id ASC
  `).all() as any[];

  // Format to match both legacy frontend and full relational standard
  const result = outlets.map(o => ({
    id: o.id,
    campus_id: o.campus_id,
    name: o.outlet_name,
    outlet_name: o.outlet_name,
    slug: o.slug,
    description: o.description,
    location: o.location,
    opening_time: o.opening_time,
    closing_time: o.closing_time,
    status: o.outlet_status,
    outlet_status: o.outlet_status,
    crowd_level: o.crowd_level,
    avg_wait_min: o.avg_wait_min,
    available_tables: o.available_tables ?? 4,
    total_items: o.total_items,
    vendor_owner_id: o.vendor_owner_id,
  }));

  res.json(result);
});

// GET /api/outlets/:id
router.get('/:id', (req, res) => {
  const outlet = db.prepare(`
    SELECT o.*,
      (SELECT COUNT(*) FROM outlet_tables t WHERE t.outlet_id = o.id AND t.status = 'available') AS available_tables
    FROM outlets o
    WHERE o.id = ?
  `).get(req.params.id) as any;

  if (!outlet) {
    res.status(404).json({ detail: "Outlet not found." });
    return;
  }

  res.json({
    id: outlet.id,
    campus_id: outlet.campus_id,
    name: outlet.outlet_name,
    outlet_name: outlet.outlet_name,
    slug: outlet.slug,
    description: outlet.description,
    location: outlet.location,
    status: outlet.outlet_status,
    outlet_status: outlet.outlet_status,
    crowd_level: outlet.crowd_level,
    avg_wait_min: outlet.avg_wait_min,
    available_tables: outlet.available_tables ?? 4,
  });
});

// GET /api/outlets/:outletId/menu (Structured category tree)
router.get('/:outletId/menu', (req, res) => {
  const outletId = parseInt(req.params.outletId, 10);
  const outlet = db.prepare('SELECT * FROM outlets WHERE id = ?').get(outletId);
  if (!outlet) {
    res.status(404).json({ detail: "Outlet not found." });
    return;
  }

  const categories = db.prepare(`
    SELECT * FROM menu_categories
    WHERE outlet_id = ? AND is_active = 1
    ORDER BY display_order ASC, id ASC
  `).all(outletId) as any[];

  const items = db.prepare(`
    SELECT * FROM menu_items
    WHERE outlet_id = ? AND is_active = 1
    ORDER BY display_order ASC, id ASC
  `).all(outletId) as any[];

  const result = categories.map(cat => ({
    id: cat.id,
    name: cat.category_name,
    category_name: cat.category_name,
    description: cat.description,
    display_order: cat.display_order,
    items: items
      .filter(i => i.category_id === cat.id)
      .map(i => ({
        id: i.id,
        outlet_id: i.outlet_id,
        category_id: i.category_id,
        name: i.item_name,
        item_name: i.item_name,
        description: i.description,
        price: i.price,
        image_url: i.image_url,
        prep_minutes: i.preparation_time,
        preparation_time: i.preparation_time,
        food_type: i.food_type,
        dietary_type: i.food_type,
        dietary_tags: typeof i.dietary_tags === 'string' ? JSON.parse(i.dietary_tags || '[]') : i.dietary_tags,
        allergens: typeof i.allergens === 'string' ? JSON.parse(i.allergens || '[]') : i.allergens,
        is_jain: i.food_type === 'jain',
        is_available: i.availability_status === 'available',
        availability_status: i.availability_status,
        available_quantity: i.stock_quantity,
        stock_quantity: i.stock_quantity,
        rating: i.rating,
        is_popular: Boolean(i.is_popular),
      })),
  }));

  res.json(result);
});

// POST /api/outlets (Admin only)
router.post('/', requireAdmin, (req, res) => {
  const { campus_id, outlet_name, slug, description, location, opening_time, closing_time } = req.body;
  if (!outlet_name || !location) {
    res.status(400).json({ detail: "Outlet name and location required." });
    return;
  }
  const cleanSlug = slug || outlet_name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  try {
    const info = db.prepare(`
      INSERT INTO outlets (campus_id, outlet_name, slug, description, location, opening_time, closing_time, outlet_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
    `).run(campus_id || 1, outlet_name, cleanSlug, description || '', location, opening_time || '08:00', closing_time || '20:00');
    const created = db.prepare('SELECT * FROM outlets WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json(created);
  } catch (err: any) {
    res.status(400).json({ detail: err.message || "Failed to create outlet." });
  }
});

// PATCH /api/outlets/:id (Vendor/Admin)
router.patch('/:id', requireVendorOrAdmin, (req, res) => {
  const { outlet_name, description, location, crowd_level, avg_wait_min, outlet_status } = req.body;
  const updates: string[] = [];
  const params: any[] = [];

  if (outlet_name !== undefined) { updates.push('outlet_name = ?'); params.push(outlet_name); }
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (location !== undefined) { updates.push('location = ?'); params.push(location); }
  if (crowd_level !== undefined) { updates.push('crowd_level = ?'); params.push(crowd_level); }
  if (avg_wait_min !== undefined) { updates.push('avg_wait_min = ?'); params.push(avg_wait_min); }
  if (outlet_status !== undefined) { updates.push('outlet_status = ?'); params.push(outlet_status); }

  if (updates.length === 0) {
    res.status(400).json({ detail: "No update parameters." });
    return;
  }

  updates.push('updated_at = CURRENT_TIMESTAMP');
  params.push(req.params.id);

  db.prepare(`UPDATE outlets SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const updated = db.prepare('SELECT * FROM outlets WHERE id = ?').get(req.params.id);
  res.json(updated);
});

export default router;
