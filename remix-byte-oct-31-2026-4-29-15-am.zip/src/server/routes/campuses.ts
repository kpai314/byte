import { Router } from 'express';
import { db } from '../db';
import { requireAdmin } from '../middleware/auth';

const router = Router();

// GET /api/campuses
router.get('/', (_req, res) => {
  const campuses = db.prepare('SELECT * FROM campuses ORDER BY id ASC').all();
  res.json(campuses);
});

// GET /api/campuses/:id
router.get('/:id', (req, res) => {
  const campus = db.prepare('SELECT * FROM campuses WHERE id = ?').get(req.params.id);
  if (!campus) {
    res.status(404).json({ detail: "Campus not found." });
    return;
  }
  res.json(campus);
});

// POST /api/campuses (Admin only)
router.post('/', requireAdmin, (req, res) => {
  const { name, location, campus_code, status } = req.body;
  if (!name || !location || !campus_code) {
    res.status(400).json({ detail: "Name, location, and campus code are required." });
    return;
  }
  try {
    const info = db.prepare(`
      INSERT INTO campuses (name, location, campus_code, status)
      VALUES (?, ?, ?, ?)
    `).run(name, location, campus_code.toUpperCase(), status || 'active');
    const created = db.prepare('SELECT * FROM campuses WHERE id = ?').get(info.lastInsertRowid);
    res.status(201).json(created);
  } catch (err: any) {
    res.status(400).json({ detail: err.message || "Failed to create campus." });
  }
});

// PATCH /api/campuses/:id (Admin only)
router.patch('/:id', requireAdmin, (req, res) => {
  const { name, location, status } = req.body;
  const updates: string[] = [];
  const params: any[] = [];

  if (name !== undefined) { updates.push('name = ?'); params.push(name); }
  if (location !== undefined) { updates.push('location = ?'); params.push(location); }
  if (status !== undefined) { updates.push('status = ?'); params.push(status); }

  if (updates.length === 0) {
    res.status(400).json({ detail: "No update parameters provided." });
    return;
  }

  updates.push('updated_at = CURRENT_TIMESTAMP');
  params.push(req.params.id);

  db.prepare(`UPDATE campuses SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const updated = db.prepare('SELECT * FROM campuses WHERE id = ?').get(req.params.id);
  res.json(updated);
});

export default router;
