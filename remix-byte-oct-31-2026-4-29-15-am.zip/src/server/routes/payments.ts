import { Router } from 'express';
import { db } from '../db';
import { requireAuth } from '../middleware/auth';

const router = Router();

// GET /api/payments/:orderId
router.get('/:orderId', requireAuth, (req, res) => {
  const payment = db.prepare(`
    SELECT p.*, o.order_number, o.user_id
    FROM payments p
    JOIN orders o ON p.order_id = o.id
    WHERE p.order_id = ?
  `).get(req.params.orderId) as any;

  if (!payment) {
    res.status(404).json({ detail: "Payment record not found." });
    return;
  }

  // Authorization check
  if (payment.user_id !== req.user!.id && !['Admin', 'Vendor'].includes(req.user!.operational_role)) {
    res.status(403).json({ detail: "Not authorized to access payment." });
    return;
  }

  res.json({
    id: payment.id,
    order_id: payment.order_id,
    order_number: payment.order_number,
    payment_provider: payment.payment_provider,
    payment_reference: payment.payment_reference,
    amount: payment.amount,
    payment_method: payment.payment_method,
    payment_status: payment.payment_status,
    created_at: payment.created_at,
  });
});

// POST /api/payments/verify (Sandbox UPI simulation verification)
router.post('/verify', requireAuth, (req, res) => {
  const { payment_reference, order_id } = req.body;
  if (!payment_reference || !order_id) {
    res.status(400).json({ detail: "payment_reference and order_id are required." });
    return;
  }

  const payment = db.prepare('SELECT * FROM payments WHERE payment_reference = ? AND order_id = ?').get(payment_reference, order_id) as any;
  if (!payment) {
    res.status(404).json({ detail: "Payment record not found." });
    return;
  }

  res.json({
    verified: true,
    payment_reference: payment.payment_reference,
    amount: payment.amount,
    payment_status: payment.payment_status,
    message: "Sandbox payment verified — no real monetary transaction executed.",
  });
});

export default router;
