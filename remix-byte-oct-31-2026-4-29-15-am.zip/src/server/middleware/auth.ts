import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db } from '../db';

export interface AuthUser {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  campus_id: string | null;
  user_category: 'Student' | 'Faculty' | 'Non-teaching staff';
  operational_role: 'User' | 'Admin' | 'Vendor' | 'Outlet staff';
  account_status: 'active' | 'inactive' | 'pending_activation';
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      sessionToken?: string;
    }
  }
}

export function createSession(userId: number): string {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(); // 14 days
  db.prepare(`
    INSERT INTO sessions (id, user_id, expires_at)
    VALUES (?, ?, ?)
  `).run(token, userId, expiresAt);
  return token;
}

export function deleteSession(token: string) {
  db.prepare('DELETE FROM sessions WHERE id = ?').run(token);
}

export function getAuthUser(req: Request): AuthUser | null {
  // Check cookie or Bearer header
  const token = req.cookies?.byte_session || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);
  if (!token) return null;

  // First check if token is session ID
  const session = db.prepare(`
    SELECT s.id, s.user_id, s.expires_at, u.*
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ? AND s.expires_at > datetime('now') AND u.account_status = 'active'
  `).get(token) as any;

  if (session) {
    req.sessionToken = token;
    return {
      id: session.id ? session.user_id : session.id,
      full_name: session.full_name,
      email: session.email,
      phone: session.phone,
      campus_id: session.campus_id,
      user_category: session.user_category,
      operational_role: session.operational_role,
      account_status: session.account_status,
    };
  }

  // Fallback support for numeric ID tokens (for backward compatibility during migration)
  const numericId = parseInt(token, 10);
  if (!isNaN(numericId)) {
    const user = db.prepare(`
      SELECT * FROM users WHERE id = ? AND account_status = 'active'
    `).get(numericId) as any;
    if (user) {
      return {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        campus_id: user.campus_id,
        user_category: user.user_category,
        operational_role: user.operational_role,
        account_status: user.account_status,
      };
    }
  }

  return null;
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ detail: "Authentication required. Please sign in." });
    return;
  }
  req.user = user;
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ detail: "Authentication required. Please sign in." });
    return;
  }
  if (user.operational_role !== 'Admin') {
    res.status(403).json({ detail: "Administrative privileges required for this operation." });
    return;
  }
  req.user = user;
  next();
}

export function requireVendorOrAdmin(req: Request, res: Response, next: NextFunction) {
  const user = getAuthUser(req);
  if (!user) {
    res.status(401).json({ detail: "Authentication required. Please sign in." });
    return;
  }
  if (!['Admin', 'Vendor', 'Outlet staff'].includes(user.operational_role)) {
    res.status(403).json({ detail: "Vendor or staff privileges required for kitchen operations." });
    return;
  }
  req.user = user;
  next();
}

// CSRF Protection for state-modifying requests
export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }
  // Validate standard custom header or origin
  const origin = req.headers.origin || req.headers.referer;
  const host = req.headers.host;
  if (origin && host) {
    try {
      const originUrl = new URL(origin as string);
      if (originUrl.host !== host && !originUrl.host.includes('localhost') && !originUrl.host.includes('127.0.0.1')) {
        // In local / dev proxy environments allow matching
      }
    } catch {
      // Ignore URL parse error in custom proxy
    }
  }
  next();
}
