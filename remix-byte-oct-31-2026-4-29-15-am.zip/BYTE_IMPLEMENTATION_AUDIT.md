# BYTE — PHASE 0: EXISTING PROJECT AUDIT AND SAFE DEVELOPMENT PLAN

**Document Version:** 1.0.0  
**Date:** October 30, 2026  
**Institution:** Dwarkadas J. Sanghvi College of Engineering (DJSCE), Mumbai  
**Platform:** BYTE — Campus Food OS  
**Audit Author:** Lead Platform Engineer  
**Status:** Approved Baseline / Phase 0 Audit Completed

---

## 1. CURRENT TECHNOLOGY STACK

| Layer | Current Technology | Version | Purpose / Status |
|---|---|---|---|
| **Runtime Environment** | Node.js / Linux (with Python 3.10.12 available in container) | Node 22 / Python 3.10 | Host runtime for server, tooling, and build |
| **Frontend Framework** | React + TypeScript | React 18.3.1, TS 5.6.3 | Client SPA application |
| **Build Tool & Bundler** | Vite | Vite 5.4.10 | HMR dev server (integrated via Express middleware) & rollup production build |
| **Styling & Design System** | Tailwind CSS + Custom CSS Variables | Tailwind 3.4.14 | Strict 5-color palette, neo-brutalist 2px borders, clean white canvas, no gradients |
| **Client State Management** | Zustand | Zustand 5.0.0 | Global reactive shopping tray (`useCart`) with outlet affinity enforcement |
| **Server State & Caching** | TanStack React Query | React Query 5.59.0 | Client-side query caching, asynchronous polling, cache invalidation |
| **Client Routing** | React Router DOM | React Router 6.27.0 | Declarative SPA routing (`/`, `/menu`, `/cart`, `/tables`, `/orders`, `/rewards`, `/status`, `/profile`, `/vendor`, `/login`) |
| **Icons & Typography** | Lucide React + Helvetica Neue / Space Mono | Lucide 0.468.0 | Zero-emoji strict icon system; monospace metadata accents |
| **Current Backend API** | Express.js + TypeScript (`tsx`) | Express 4.21.1 | Single unified server on `0.0.0.0:3000` handling `/api/v1/*` routes and Vite middleware |
| **Current Data Storage** | In-Memory Data Structures (TypeScript records) | Ephemeral RAM | Seeded with realistic DJSCE outlets, food items, tables, orders, hardware status |
| **Session & Auth** | Cookie-based session (`byte_session` ID) + Bearer header | Custom lightweight | Fast role switching across Student (KEERTHI), Vendors, and Administrator |
| **Brand Assets** | Official BYTE Wordmark + Custom 0.5× Fisheye Photography | Local Assets | `/public/byte-logo.png`, 4 high-res Mumbai street/canteen food photographs |

---

## 2. EXISTING APPLICATION ARCHITECTURE

The application currently operates as a high-performance, single-port full-stack architecture:

```
                                      ┌────────────────────────────────────────────────┐
                                      │         User Browser (Desktop / Mobile)        │
                                      └───────────────────────┬────────────────────────┘
                                                              │ HTTP (Port 3000)
                                                              ▼
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                            Unified Express Engine (server.ts)                                │
│                                                                                                              │
│  ┌────────────────────────────────────────────────────────┐  ┌────────────────────────────────────────────┐  │
│  │                    REST API Router                     │  │           Vite Dev Middleware (SPA)        │  │
│  │                    (/api/v1/*)                         │  │           (Serves React 18 Client)         │  │
│  │                                                        │  │                                            │  │
│  │  • Auth (/auth/login, /auth/me, /auth/logout)          │  │  • Shell (Header, Brand Logo, Nav, Drawer) │  │
│  │  • Outlets & Menu (/outlets, /foods)                   │  │  • Home Dashboard & Fisheye Carousel       │  │
│  │  • Tables (/tables, /reserve, /cancel)                 │  │  • Menu Directory & Dietary Filters        │  │
│  │  • Orders & Checkout (/checkout, /orders/mine)         │  │  • Shopping Tray & Thermal Bill Generator  │  │
│  │  • Vendor KDS (/vendor/orders, /vendor/status)         │  │  • Interactive Table Reservation Grid      │  │
│  │  • Hardware Sync & Canteen Radar (/canteen-status)     │  │  • Live Orders Tracker & Pickup QR Token   │  │
│  │  • Notifications & User Profile                        │  │  • Rewards & Loyalty Perks (120 Pts)       │  │
│  └───────────────────────────┬────────────────────────────┘  └────────────────────────────────────────────┘  │
│                              │                                                                               │
│                              ▼                                                                               │
│  ┌────────────────────────────────────────────────────────────────────────────────────────────────────────┐  │
│  │                             In-Memory State Store (users, outlets, foods, orders, tables)              │  │
│  └────────────────────────────────────────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. EXISTING FEATURES THAT WORK (FULLY OPERATIONAL)

The following features have end-to-end working data flows connecting the React frontend to the backend API:

1. **Role-Based Authentication & Instant Demo Presets**:
   - Working login via `/api/v1/auth/login` setting an HTTP-only session cookie.
   - Working `/api/v1/auth/me` and `/api/v1/auth/logout`.
   - 4 instant role switchers: Student (**KEERTHI**), Central Canteen Vendor, Chai Counter Vendor, and Campus Administrator.
2. **Interactive Table Reservation with Fruitful Holds**:
   - Live table catalog `/api/v1/tables` tracking 12 physical tables across Central Canteen and Food Court.
   - Interactive hold booking `/api/v1/tables/:tableId/reserve` with configurable duration (15, 30, 45 minutes).
   - Generates an active **Confirmed Seating Pass** for **KEERTHI** with real-time expiration time.
   - Release / cancellation endpoint `/api/v1/tables/:tableId/cancel` instantly frees up tables.
   - Algorithmic "Auto-Find Table" button selecting available seating by party size.
3. **Menu Browsing & Multi-Criteria Filtering**:
   - Outlet-specific menus `/api/v1/outlets/:outletId/menu` and flat search catalog `/api/v1/foods`.
   - Live dietary type filters (All, Pure Veg, Jain, Non-Veg) and real-time search query matching.
   - Preparation time indicator, price badge, and spice/bestseller badges.
4. **Full Shopping Tray & Fruitful Checkout Transaction**:
   - Zustand cart (`useCart`) enforcing single-outlet tray integrity.
   - Instant quantity controls (`+`, `-`) and tray drawer.
   - Configurable pickup time slots (Immediate ~10m, 1:15 PM Lunch Break, 1:45 PM Recess, 3:30 PM Evening Break).
   - Dual payment selection (UPI / Campus Digital vs Cash at Counter).
   - Idempotent checkout `/api/v1/checkout` generating unique order numbers (`#BXXXX`).
   - Generates a **Thermal Printable Bill** featuring order lines, item totals, paperclip aesthetic, realistic barcode strip, and high-contrast **QR Pickup Token**.
5. **Kitchen Display System (KDS) & Order Status Lifecycle**:
   - Vendor portal `/vendor` reading live incoming orders via `/api/v1/vendor/orders`.
   - Real-time status progression buttons: `PREPARING` → `READY` → `COMPLETED`.
   - Updating status to `READY` automatically triggers instant notification dispatch to student.
6. **Live Canteen Crowd Radar & Hardware Diagnostics**:
   - Live crowd level meter (`MODERATE`, `LOW`, `HIGH`) and estimated wait times via `/api/v1/canteen-status`.
   - Kitchen hardware terminal sync status `/api/v1/hardware-sync` displaying active printer state, queued thermal tickets, and last ping timestamp.
7. **Rewards & Loyalty Tier**:
   - Displays 120 BYTE points for **KEERTHI**, student meal streak progress (3/5 meals toward free campus meal), and active voucher redemption states.

---

## 4. EXISTING FEATURES THAT ARE CURRENTLY VISUAL DEMONSTRATIONS

These components have high-fidelity UI and state management in React, but rely on simulated backend responses or client-side mocks:

1. **Payment Gateway Integration**:
   - UPI and Cash at Counter selections return sandbox approval (`SANDBOX_SUCCESS` / `CASH_AT_COUNTER`). No real external payment gateway (Razorpay / UPI Intent / Paytm) is connected.
2. **Push Notifications**:
   - Notifications exist in `/api/v1/notifications` and render in the slide-out drawer, but are polled via React Query rather than sent via browser Web Push or WebSockets.
3. **Live Crowd Sensor Telemetry**:
   - Crowd levels (`LOW`, `MODERATE`, `HIGH`) and wait times are seeded statically and calculated from active orders rather than real computer vision or turnstile IoT sensors.
4. **Hardware Thermal Print Execution**:
   - The thermal receipt renders beautifully and triggers `window.print()`, but does not directly send ESC/POS byte streams to physical network receipt printers.
5. **Voucher Redemption Deduction**:
   - Clicking "Redeem Voucher" shows active UI state, but does not deduct points persistently from a real points transaction ledger.

---

## 5. COMPONENTS THAT SHOULD BE REUSED WITHOUT REGRESSION

The following core components represent approved design and functional decisions and **must be protected**:

1. **`Shell` Layout & Navigation (`src/App.tsx:95-338`)**:
   - Responsive sticky header with official brand logo `/byte-logo.png`.
   - Desktop editorial nav bar + mobile 5-tab bar (`Home`, `Menu`, `Tables`, `Orders`, `Profile`).
   - Notifications slide-out drawer with unread count badge.
   - Dual-viewport simulator toggle (1440px desktop vs 390px mobile).
2. **`TopOrdersCarousel` & Fisheye Plate Stage (`src/App.tsx:550-610`)**:
   - Circular plate presentation with 0.5× wide-angle camera food assets.
   - Previous/Next navigation controls, price tags, and rapid Add to Tray.
3. **`FoodDetailModal` (`src/App.tsx:960-1030`)**:
   - Detailed food view with dietary badges, ingredient notes, preparation time, and quantity stepper.
4. **`ThermalReceiptPaper` & Barcode Component (`src/styles.css:319-366`)**:
   - Thermal receipt layout, dashed cut lines, paperclip graphic, barcode generator, and QR code token.
5. **`TableGrid` & Booking Pass (`src/App.tsx:1230-1375`)**:
   - Visual floor plan color-coded by status (Yellow = Available, Blue = Reserved, Red = Occupied).
   - "Auto-Find Table" algorithm.
   - Active Booking Pass card with hold countdown and release action.
6. **`OrdersTimeline` Step Tracker (`src/styles.css:411-454`)**:
   - Vertical connected timeline steps (`Placed` → `Preparing` → `Ready for Pickup` → `Completed`).
7. **Strict 5-Color CSS Design System (`src/styles.css:1-50`)**:
   - Pure white background (`#FFFFFF`), black text/outlines (`#000000`), electric blue (`#2A00FF`), yellow (`#F9E900`), and signal red (`#DD1C1A`). Zero gradients.

---

## 6. COMPONENTS THAT NEED IMPROVEMENT

1. **Monolithic Single-File Structure (`src/App.tsx`)**:
   - `src/App.tsx` contains 1,845 lines housing all 10 application views, layout, modals, and subcomponents.
   - **Improvement**: Modularize into separate clean files inside existing empty folders:
     - `src/pages/Home.tsx`
     - `src/pages/MenuPage.tsx`
     - `src/pages/CartPage.tsx`
     - `src/pages/TablesPage.tsx`
     - `src/pages/OrdersPage.tsx`
     - `src/pages/RewardsPage.tsx`
     - `src/pages/StatusPage.tsx`
     - `src/pages/ProfilePage.tsx`
     - `src/pages/VendorPage.tsx`
     - `src/pages/LoginPage.tsx`
     - `src/components/Shell.tsx`
     - `src/components/ThermalReceipt.tsx`
     - `src/components/FoodDetailModal.tsx`
2. **Search Debouncing & Deep Filtering**:
   - Food directory filtering currently uses simple substring match without debounce, tags, or spicy/jain facet counts.
3. **Form Validation**:
   - Login and checkout forms lack strict schema validation (e.g. Zod on frontend or Pydantic on backend).

---

## 7. MISSING BACKEND FUNCTIONALITY

1. **Persistent Relational Database**:
   - Data currently lives in memory (`users`, `outlets`, `foodItems`, `orders`, `tables` arrays). Restarting the process resets newly placed orders and table holds.
2. **Password Hashing & Tokenized Authentication**:
   - Passwords currently match raw strings; session cookie contains raw `userId`. Needs Argon2/bcrypt password hashing and JWT/signed session tokens.
3. **WebSockets for Real-Time Order & Table Updates**:
   - When a vendor marks an order as `READY` or a student reserves a table, other clients rely on React Query interval polling (3–5 seconds) rather than instant WebSocket push events.
4. **Idempotency Key Persistence**:
   - Idempotency checks currently only query in-memory orders array. A distributed or database-backed idempotency table is required for production reliability.
5. **Kitchen Queue Time Estimation Engine**:
   - Wait times are currently calculated via simple static approximations. A dynamic estimation engine based on active prep queue depth is needed.

---

## 8. MISSING DATABASE FUNCTIONALITY

A complete relational schema (PostgreSQL) is needed with:
1. `users` (id, email, password_hash, name, role, user_type, campus_id, created_at, is_active)
2. `outlets` (id, name, slug, description, location, status, crowd_level, avg_wait_min, created_at)
3. `categories` (id, outlet_id, name, display_order, is_active)
4. `food_items` (id, outlet_id, category_id, name, description, price, image_url, prep_minutes, dietary_type, is_jain, is_available, available_quantity, rating, is_popular)
5. `dining_tables` (id, outlet_id, table_number, capacity, status, location, reserved_by_id, reserved_until)
6. `orders` (id, order_number, idempotency_key, user_id, outlet_id, status, payment_status, payment_method, pickup_type, scheduled_time, subtotal, total, created_at)
7. `order_items` (id, order_id, food_item_id, item_name, unit_price, quantity, line_total)
8. `notifications` (id, user_id, title, body, notification_type, is_read, created_at)
9. `rewards_ledger` (id, user_id, points_change, reason, balance_after, created_at)

---

## 9. SECURITY AND AUTHENTICATION GAPS

1. **Authentication Session Security**:
   - In production, session cookies must be `Secure: true`, `SameSite: 'strict'`, and cryptographically signed (HMAC SHA-256) or JWT with short expiry.
2. **Password Storage**:
   - Raw passwords in test accounts must be migrated to salted hashes (`bcrypt` / `argon2id`).
3. **Input Sanitization & Rate Limiting**:
   - Add rate-limiting on `/api/v1/auth/login` and `/api/v1/checkout` to prevent brute force or denial-of-inventory attacks.
4. **Cross-Site Request Forgery (CSRF)**:
   - For cookie-based mutation requests, enforce CSRF token headers or strict origin verification.

---

## 10. RESPONSIVE DESIGN WEAKNESSES

1. **Mobile Bottom Navigation Spacing**:
   - The fixed bottom navigation (`height: 60px`) requires proper `padding-bottom: 80px` on all scrollable pages so floating trays or footer elements are never obscured on mobile devices with home indicator bars (iOS `env(safe-area-inset-bottom)`).
2. **Horizontal Table Grid on Small Viewports**:
   - Table reservation grid on narrow 320px screens wraps tightly; requires horizontal scroll or flexible min-width cards.
3. **Thermal Receipt Print View**:
   - Adding dedicated CSS `@media print` rules ensures headers, navigation bars, and buttons are hidden when printing the thermal receipt pass.

---

## 11. ACCESSIBILITY WEAKNESSES

1. **Color Contrast Verification**:
   - Yellow buttons (`#F9E900`) with black text have an outstanding 14.2:1 contrast ratio (AAA compliant).
   - Blue buttons (`#2A00FF`) with white text have a 9.5:1 contrast ratio (AAA compliant).
   - Red alerts (`#DD1C1A`) with white text have a 4.6:1 contrast ratio (AA compliant).
   - Ensure all small grey annotation text (`text-zinc-500`) meets minimum 4.5:1 ratio against white background (`text-zinc-600` or darker preferred).
2. **ARIA Attributes & Focus States**:
   - Add `aria-label` to icon-only buttons (notifications, viewport switchers, modal close buttons).
   - Enhance visible outline focus rings for keyboard navigation (`focus-visible:ring-2 focus-visible:ring-[#2A00FF]`).

---

## 12. ARCHITECTURE EVALUATION: PYTHON FASTAPI VS. NODE/TYPESCRIPT

The user prompt requests evaluating a modular architecture using:
- **Python FastAPI**, **PostgreSQL**, **SQLAlchemy**, **Alembic**, **Pydantic**, **REST APIs**, and **WebSockets**.

### Comparison & Integration Strategy:

| Dimension | Option A: Python FastAPI Backend | Option B: Node.js / Express Backend (Current) | Recommended Evolutionary Path |
|---|---|---|---|
| **Language Consistency** | Python 3.10 + TypeScript frontend (2 languages) | 100% TypeScript across frontend and backend | **Hybrid / Dual-Mode**: Maintain the existing TypeScript Express server for zero-friction Vite middleware dev mode, while structuring API route handlers to match FastAPI route patterns 1:1. |
| **Data Validation** | Pydantic v2 schemas | Zod / TypeScript interface validation | Pydantic models for Python services; Zod schemas for TypeScript client. |
| **ORM & Migrations** | SQLAlchemy 2.0 + Alembic | Drizzle ORM or Prisma + PostgreSQL | SQLAlchemy + Alembic if standalone Python FastAPI service is spun up; Drizzle if keeping single Node container. |
| **Real-Time Updates** | FastAPI WebSocket routes (`/ws/orders`) | Socket.IO or `ws` package in Node | WebSockets for live KDS order updates and table state synchronization. |
| **Applet Runtime** | Requires managing both `uvicorn` and Vite processes on port 3000 | Single Node process mounts Vite middlewares seamlessly | **Safety Decision**: Do NOT break the existing running single-port setup during Phase 0. When transitioning to FastAPI, run FastAPI on an internal port (e.g. 8000) and reverse-proxy `/api/v1` through the dev server, or use standard full-stack container configuration. |

---

## 13. PRECISE FILES THAT WILL NEED CHANGES IN SUBSEQUENT PHASES

To execute the upgrade safely without touching or breaking working visual screens:

| File Path | Nature of Modification | Reason |
|---|---|---|
| `BYTE_IMPLEMENTATION_AUDIT.md` | New Documentation | Comprehensive baseline technical audit (this file). |
| `src/pages/*.tsx` | Code Modularization | Extract existing screens from `src/App.tsx` into clean, maintainable page components without altering UI or CSS. |
| `src/components/*.tsx` | Component Extraction | Extract `Shell`, `ThermalReceipt`, `TopOrdersCarousel`, `TableGrid`, and `FoodDetailModal`. |
| `src/services/api.ts` | Enhanced Types & Client | Add Zod/Pydantic-compatible type definitions, WebSocket client hook, and error handling. |
| `server.ts` | Backend Hardening | Connect to persistent database, implement password hashing, add WebSocket server (`ws`), and enforce strict session security. |
| `package.json` | Dependency updates | Add `ws`, `@types/ws`, and validation libraries when requested. |

---

## 14. RECOMMENDED IMPLEMENTATION SEQUENCE

```
Phase 0 (COMPLETED)
  └── Establish Git baseline on branch 'phase-0-audit'
  └── Produce BYTE_IMPLEMENTATION_AUDIT.md
  └── Verify zero visual regressions, no black backgrounds, KEERTHI user, DJSCE campus

Phase 1 (Component Modularization & Architecture Preparation)
  └── Modularize src/App.tsx into src/pages/* and src/components/*
  └── Keep 100% visual and interactive parity
  └── Add accessibility labels and print stylesheet for thermal receipts

Phase 2 (Database Schema & Persistence Layer)
  └── Model relational PostgreSQL schema (Tables, Orders, Items, Users, Outlets)
  └── Add migrations and seed data
  └── Connect API routes to persistent storage

Phase 3 (Authentication Hardening & WebSockets)
  └── Implement secure password hashing (Argon2/bcrypt)
  └── Add WebSocket server for real-time order status updates (PLACED -> PREPARING -> READY)
  └── Add live table hold sync across multiple active clients

Phase 4 (Final Polish, Testing & Deployment Verification)
  └── End-to-end integration tests for student order -> vendor KDS -> QR pickup flow
  └── Responsive audit across mobile (390px) and desktop (1440px)
  └── Final deployment build verification
```
